package com.example

import com.example.audio.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testTrackCreationAndDefaults() {
        val track = Track(
            name = "Test 808",
            type = InstrumentType.DRUMS,
            colorHex = 0xFF00E5FF
        )
        assertEquals("Test 808", track.name)
        assertEquals(0.8f, track.volume)
        assertEquals(0.0f, track.pan)
        assertFalse(track.isMuted)
        assertFalse(track.isSolo)
        assertEquals(16, track.steps.size)
    }

    @Test
    fun testEffectChainAddition() {
        val effect = EffectInstance(
            type = EffectType.EQ_3CHI,
            eqParams = EQ3ChiParams(chi1Gain = 3.0f)
        )
        val track = Track(
            name = "Vocal Track",
            type = InstrumentType.AUDIO_VOCAL,
            colorHex = 0xFFFFC107,
            effects = listOf(effect)
        )
        assertEquals(1, track.effects.size)
        assertEquals(EffectType.EQ_3CHI, track.effects[0].type)
        assertEquals(3.0f, track.effects[0].eqParams.chi1Gain)
    }

    @Test
    fun testAllFourEffectTypesAvailable() {
        val types = EffectType.values()
        assertEquals(4, types.size)
        assertTrue(types.contains(EffectType.EQ_3CHI))
        assertTrue(types.contains(EffectType.AURA_COMP))
        assertTrue(types.contains(EffectType.AURA_SPACE))
        assertTrue(types.contains(EffectType.AURA_MAXIMIZER))
    }
}
