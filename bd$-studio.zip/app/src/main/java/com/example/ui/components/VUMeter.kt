package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

@Composable
fun StereoVUMeter(
    rmsL: Float,
    rmsR: Float,
    modifier: Modifier = Modifier,
    segments: Int = 12
) {
    Row(
        modifier = modifier
            .height(28.dp)
            .width(56.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        SingleVUMeter(level = rmsL, modifier = Modifier.weight(1f), segments = segments)
        SingleVUMeter(level = rmsR, modifier = Modifier.weight(1f), segments = segments)
    }
}

@Composable
fun SingleVUMeter(
    level: Float,
    modifier: Modifier = Modifier,
    segments: Int = 12
) {
    Canvas(modifier = modifier.fillMaxHeight()) {
        val totalHeight = size.height
        val totalWidth = size.width
        val segmentGap = 2.dp.toPx()
        val segmentHeight = (totalHeight - (segments - 1) * segmentGap) / segments

        val normalized = level.coerceIn(0f, 1f)
        val activeSegments = (normalized * segments).toInt().coerceIn(0, segments)

        for (i in 0 until segments) {
            // Draw from bottom to top
            val segmentIndexFromBottom = i
            val yTop = totalHeight - (i + 1) * segmentHeight - i * segmentGap

            val segmentColor = when {
                i >= segments - 2 -> VuRed
                i >= segments - 4 -> VuOrange
                i >= segments - 6 -> VuYellow
                else -> VuGreen
            }

            val isActive = segmentIndexFromBottom < activeSegments
            val drawColor = if (isActive) segmentColor else segmentColor.copy(alpha = 0.15f)

            drawRect(
                color = drawColor,
                topLeft = Offset(0f, yTop),
                size = Size(totalWidth, segmentHeight)
            )
        }
    }
}

@Composable
fun HorizontalVUMeter(
    level: Float,
    modifier: Modifier = Modifier,
    segments: Int = 16
) {
    Canvas(modifier = modifier.fillMaxWidth().height(8.dp)) {
        val totalWidth = size.width
        val totalHeight = size.height
        val segmentGap = 2.dp.toPx()
        val segmentWidth = (totalWidth - (segments - 1) * segmentGap) / segments

        val normalized = level.coerceIn(0f, 1f)
        val activeSegments = (normalized * segments).toInt().coerceIn(0, segments)

        for (i in 0 until segments) {
            val xLeft = i * (segmentWidth + segmentGap)

            val segmentColor = when {
                i >= segments - 3 -> VuRed
                i >= segments - 6 -> VuOrange
                i >= segments - 9 -> VuYellow
                else -> VuGreen
            }

            val isActive = i < activeSegments
            val drawColor = if (isActive) segmentColor else segmentColor.copy(alpha = 0.15f)

            drawRect(
                color = drawColor,
                topLeft = Offset(xLeft, 0f),
                size = Size(segmentWidth, totalHeight)
            )
        }
    }
}
