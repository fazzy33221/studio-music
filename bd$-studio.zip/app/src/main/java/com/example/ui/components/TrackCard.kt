package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.EffectInstance
import com.example.audio.InstrumentType
import com.example.audio.Track
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun TrackCard(
    track: Track,
    currentStep: Int,
    isPlaying: Boolean,
    onVolumeChange: (Float) -> Unit,
    onPanChange: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onToggleSolo: () -> Unit,
    onToggleStep: (Int) -> Unit,
    onPreviewTrack: () -> Unit,
    onDeleteTrack: () -> Unit,
    onAddEffectClick: () -> Unit,
    onOpenEffect: (effectId: String) -> Unit,
    onToggleEffectBypass: (effectId: String) -> Unit,
    onRemoveEffect: (effectId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val trackColor = Color(track.colorHex)
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Card(
        colors = CardDefaults.cardColors(containerColor = StudioCard),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("track_card_${track.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Track Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Color indicator dot
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(trackColor, CircleShape)
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Instrument icon
                val icon = when (track.type) {
                    InstrumentType.DRUMS -> Icons.Default.MusicNote
                    InstrumentType.BASS -> Icons.Default.GraphicEq
                    InstrumentType.SYNTH_LEAD -> Icons.Default.Piano
                    InstrumentType.KEYS -> Icons.Default.Keyboard
                    InstrumentType.HI_HATS -> Icons.Default.Grain
                    InstrumentType.AUDIO_VOCAL -> Icons.Default.Mic
                }
                Icon(
                    imageVector = icon,
                    contentDescription = track.type.displayName,
                    tint = trackColor,
                    modifier = Modifier.size(18.dp)
                )

                Spacer(modifier = Modifier.width(6.dp))

                // Track name
                Text(
                    text = track.name,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )

                // Preview sound button
                IconButton(
                    onClick = onPreviewTrack,
                    modifier = Modifier.size(32.dp).testTag("btn_preview_${track.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Audicionar",
                        tint = StudioCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Delete track button
                IconButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier.size(32.dp).testTag("btn_delete_track_${track.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Eliminar pista",
                        tint = TextDisabled,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Controls Row: Mute, Solo, Volume, Pan
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Mute Button
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (track.isMuted) StudioCrimson else StudioSurfaceVariant)
                        .clickable(onClick = onToggleMute)
                        .testTag("btn_mute_${track.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "M",
                        color = if (track.isMuted) Color.White else TextSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Solo Button
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (track.isSolo) StudioGold else StudioSurfaceVariant)
                        .clickable(onClick = onToggleSolo)
                        .testTag("btn_solo_${track.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "S",
                        color = if (track.isSolo) StudioBackground else TextSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Volume Fader
                Column(modifier = Modifier.weight(1.3f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("VOL", fontSize = 10.sp, color = TextSecondary)
                        Text(
                            text = "${(track.volume * 100).roundToInt()}%",
                            fontSize = 10.sp,
                            color = StudioGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = track.volume,
                        onValueChange = onVolumeChange,
                        valueRange = 0f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = StudioGold,
                            activeTrackColor = StudioGold,
                            inactiveTrackColor = ControlTrack
                        ),
                        modifier = Modifier.height(24.dp).testTag("slider_vol_${track.id}")
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Pan Slider
                Column(modifier = Modifier.weight(1.1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("PAN", fontSize = 10.sp, color = TextSecondary)
                        val panText = when {
                            track.pan < -0.05f -> "L ${(track.pan * -100).roundToInt()}"
                            track.pan > 0.05f -> "R ${(track.pan * 100).roundToInt()}"
                            else -> "C"
                        }
                        Text(
                            text = panText,
                            fontSize = 10.sp,
                            color = StudioCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = track.pan,
                        onValueChange = onPanChange,
                        valueRange = -1f..1f,
                        colors = SliderDefaults.colors(
                            thumbColor = StudioCyan,
                            activeTrackColor = StudioCyan,
                            inactiveTrackColor = ControlTrack
                        ),
                        modifier = Modifier.height(24.dp).testTag("slider_pan_${track.id}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // EFX CHAIN Section
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "EFX CHAIN (${track.effects.size})",
                    fontSize = 10.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.weight(1f))

                // Button "AGREGAR EFX"
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(StudioGold.copy(alpha = 0.15f))
                        .border(1.dp, StudioGold.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .clickable(onClick = onAddEffectClick)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("btn_add_efx_${track.id}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Agregar EFX",
                        tint = StudioGold,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "AGREGAR EFX",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioGold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Effects Chips Row
            if (track.effects.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    track.effects.forEach { effect ->
                        EffectChip(
                            effect = effect,
                            onOpen = { onOpenEffect(effect.id) },
                            onToggleBypass = { onToggleEffectBypass(effect.id) },
                            onRemove = { onRemoveEffect(effect.id) }
                        )
                    }
                }
            } else {
                Text(
                    text = "Sin efectos en la cadena. Toca 'AGREGAR EFX' para insertar EQ 3CHI, AuraComp, etc.",
                    fontSize = 11.sp,
                    color = TextDisabled,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 16-Step Pattern Sequencer Row
            Text(
                text = "PATRÓN DE RITMO / PASOS (16)",
                fontSize = 10.sp,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                for (stepIndex in 0 until 16) {
                    val isStepActive = track.steps.getOrElse(stepIndex) { false }
                    val isCurrentPlayhead = isPlaying && currentStep == stepIndex
                    val isQuarterBeat = stepIndex % 4 == 0

                    val stepBg = when {
                        isCurrentPlayhead -> Color.White
                        isStepActive -> trackColor
                        isQuarterBeat -> StudioSurfaceVariant
                        else -> StudioCard
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(28.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(stepBg)
                            .border(
                                width = if (isCurrentPlayhead) 1.5.dp else 1.dp,
                                color = if (isCurrentPlayhead) StudioGold else StudioBorder,
                                shape = RoundedCornerShape(3.dp)
                            )
                            .clickable { onToggleStep(stepIndex) }
                            .testTag("step_${track.id}_$stepIndex"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isStepActive) {
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .background(
                                        if (isCurrentPlayhead) StudioBackground else Color.White,
                                        CircleShape
                                    )
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Eliminar Pista", color = TextPrimary) },
            text = { Text("¿Deseas eliminar '${track.name}' y sus efectos?", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteTrack()
                        showDeleteConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCrimson)
                ) {
                    Text("Eliminar", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancelar", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun EffectChip(
    effect: EffectInstance,
    onOpen: () -> Unit,
    onToggleBypass: () -> Unit,
    onRemove: () -> Unit
) {
    val effectColor = Color(effect.type.badgeColorHex)
    val isEnabled = effect.isEnabled

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isEnabled) StudioSurfaceVariant else StudioCard)
            .border(
                1.dp,
                if (isEnabled) effectColor.copy(alpha = 0.6f) else StudioBorder,
                RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onOpen)
            .padding(horizontal = 8.dp, vertical = 5.dp)
            .testTag("effect_chip_${effect.type.name}")
    ) {
        // Bypass indicator dot
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (isEnabled) effectColor else TextDisabled)
                .clickable(onClick = onToggleBypass)
        )

        Spacer(modifier = Modifier.width(6.dp))

        // Effect Name
        Text(
            text = effect.type.displayName,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (isEnabled) TextPrimary else TextDisabled
        )

        Spacer(modifier = Modifier.width(4.dp))

        // Small edit icon
        Icon(
            imageVector = Icons.Default.Tune,
            contentDescription = "Editar",
            tint = effectColor,
            modifier = Modifier.size(13.dp)
        )

        Spacer(modifier = Modifier.width(4.dp))

        // Remove button
        IconButton(
            onClick = onRemove,
            modifier = Modifier.size(18.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Eliminar efecto",
                tint = TextDisabled,
                modifier = Modifier.size(12.dp)
            )
        }
    }
}
