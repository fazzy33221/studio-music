package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun RotaryKnob(
    value: Float,
    onValueChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    label: String,
    modifier: Modifier = Modifier,
    unit: String = "",
    size: Dp = 64.dp,
    accentColor: Color = StudioGold,
    decimals: Int = 1
) {
    val rangeSpan = (range.endInclusive - range.start).coerceAtLeast(0.001f)
    val normalized = ((value - range.start) / rangeSpan).coerceIn(0f, 1f)

    var currentY by remember { mutableFloatStateOf(0f) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.testTag("knob_$label")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .pointerInput(range) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            currentY = offset.y
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            // Drag up to increase, drag down to decrease
                            val delta = -dragAmount.y / 200f
                            val newNormalized = (normalized + delta).coerceIn(0f, 1f)
                            val newValue = range.start + newNormalized * rangeSpan
                            onValueChange(newValue)
                        }
                    )
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 5.dp.toPx()
                val radius = (this.size.minDimension - strokeWidth) / 2f
                val center = Offset(this.size.width / 2f, this.size.height / 2f)

                val startAngle = 135f
                val sweepMax = 270f
                val sweepCurrent = normalized * sweepMax

                // Background track arc
                drawArc(
                    color = StudioBorder,
                    startAngle = startAngle,
                    sweepAngle = sweepMax,
                    useCenter = false,
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = Size(radius * 2, radius * 2),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )

                // Active value arc with glow
                if (sweepCurrent > 0f) {
                    drawArc(
                        color = accentColor,
                        startAngle = startAngle,
                        sweepAngle = sweepCurrent,
                        useCenter = false,
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = Size(radius * 2, radius * 2),
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }

                // Inner knob disc
                val innerRadius = radius * 0.72f
                drawCircle(
                    color = StudioSurfaceVariant,
                    radius = innerRadius,
                    center = center
                )

                // Pointer indicator line
                val currentAngleRad = Math.toRadians((startAngle + sweepCurrent).toDouble())
                val pointerStartX = center.x + innerRadius * 0.35f * cos(currentAngleRad).toFloat()
                val pointerStartY = center.y + innerRadius * 0.35f * sin(currentAngleRad).toFloat()
                val pointerEndX = center.x + innerRadius * 0.9f * cos(currentAngleRad).toFloat()
                val pointerEndY = center.y + innerRadius * 0.9f * sin(currentAngleRad).toFloat()

                drawLine(
                    color = accentColor,
                    start = Offset(pointerStartX, pointerStartY),
                    end = Offset(pointerEndX, pointerEndY),
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }

        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = TextSecondary,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
        Text(
            text = when (decimals) {
                0 -> "${value.roundToInt()}$unit"
                else -> String.format(java.util.Locale.US, "%.${decimals}f%s", value, unit)
            },
            fontSize = 10.sp,
            color = accentColor,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}
