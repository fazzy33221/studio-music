package com.example.ui.plugins

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AuraSpaceParams
import com.example.ui.components.RotaryKnob
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun AuraSpaceScreen(
    trackName: String,
    isEnabled: Boolean,
    params: AuraSpaceParams,
    onParamsChange: (AuraSpaceParams) -> Unit,
    onToggleBypass: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var showPresetMenu by remember { mutableStateOf(false) }

    // Pulsing animation for spatial reverb field
    val infiniteTransition = rememberInfiniteTransition(label = "AuraSpaceAnim")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("screen_aura_space")
    ) {
        // Top Header Bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurface)
                .border(1.dp, StudioBorder)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("btn_back_from_space")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Volver a BD$ Studio",
                    tint = StudioPurple
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "AuraSpace",
                        color = StudioPurple,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(StudioPurple.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "SPATIAL REVERB",
                            color = StudioPurple,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = "Pista: $trackName",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            // Presets Dropdown
            Box {
                Button(
                    onClick = { showPresetMenu = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioSurfaceVariant,
                        contentColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp).testTag("btn_space_presets")
                ) {
                    Text("Presets", fontSize = 11.sp)
                }

                DropdownMenu(
                    expanded = showPresetMenu,
                    onDismissRequest = { showPresetMenu = false },
                    modifier = Modifier.background(StudioSurfaceVariant)
                ) {
                    DropdownMenuItem(
                        text = { Text("Vocal Atmosphere (Hall)", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(roomSize = 4.5f, preDelayMs = 30f, dampingHz = 6500f, stereoWidth = 1.4f, mix = 0.4f, spaceType = "Hall"))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Tight Drum Room (Plate)", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(roomSize = 1.2f, preDelayMs = 10f, dampingHz = 12000f, stereoWidth = 1.1f, mix = 0.25f, spaceType = "Plate"))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Cosmic Nebula (Celestial)", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(roomSize = 8.0f, preDelayMs = 60f, dampingHz = 4000f, stereoWidth = 1.8f, mix = 0.55f, spaceType = "Celestial"))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Studio Chamber", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(roomSize = 2.4f, preDelayMs = 15f, dampingHz = 9000f, stereoWidth = 1.2f, mix = 0.3f, spaceType = "Chamber"))
                            showPresetMenu = false
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Bypass Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isEnabled) StudioEmerald else StudioCrimson)
                    .clickable(onClick = onToggleBypass)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("btn_toggle_space_bypass"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isEnabled) "ON" else "BYPASS",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Space Algorithm Selector
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("ESPACIO ACÚSTICO / ALGORITMO", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    val spaceTypes = listOf("Plate", "Hall", "Chamber", "Celestial", "Lo-Fi")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        spaceTypes.forEach { type ->
                            val isSelected = params.spaceType == type
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) StudioPurple else StudioSurfaceVariant)
                                    .clickable { onParamsChange(params.copy(spaceType = type)) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = type,
                                    color = if (isSelected) StudioBackground else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // 3D Spatial Acoustic Field Visualizer
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioPurple.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth().height(160.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().padding(10.dp)) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val center = Offset(w / 2f, h / 2f)

                        // Draw perspective room grid lines
                        val roomScale = (params.roomSize / 10f).coerceIn(0.2f, 1f)
                        val boxW = w * 0.7f * roomScale
                        val boxH = h * 0.65f * roomScale

                        // Room back wall
                        drawRect(
                            color = StudioPurple.copy(alpha = 0.12f),
                            topLeft = Offset(center.x - boxW / 2f, center.y - boxH / 2f),
                            size = androidx.compose.ui.geometry.Size(boxW, boxH)
                        )
                        drawRect(
                            color = StudioBorder,
                            topLeft = Offset(center.x - boxW / 2f, center.y - boxH / 2f),
                            size = androidx.compose.ui.geometry.Size(boxW, boxH),
                            style = Stroke(width = 1.dp.toPx())
                        )

                        // Perspective corner lines
                        val corners = listOf(
                            Offset(0f, 0f) to Offset(center.x - boxW / 2f, center.y - boxH / 2f),
                            Offset(w, 0f) to Offset(center.x + boxW / 2f, center.y - boxH / 2f),
                            Offset(0f, h) to Offset(center.x - boxW / 2f, center.y + boxH / 2f),
                            Offset(w, h) to Offset(center.x + boxW / 2f, center.y + boxH / 2f)
                        )
                        corners.forEach { (c1, c2) ->
                            drawLine(color = StudioBorder.copy(alpha = 0.7f), start = c1, end = c2, strokeWidth = 1.dp.toPx())
                        }

                        // Expanding Soundwave Rings from Center
                        val ringCount = 4
                        for (r in 0 until ringCount) {
                            val ringPhase = (pulse + r.toFloat() / ringCount) % 1.0f
                            val ringRadius = ringPhase * (w * 0.45f)
                            val ringAlpha = (1f - ringPhase) * (params.mix.coerceIn(0.2f, 1f))

                            drawCircle(
                                color = StudioPurple.copy(alpha = ringAlpha),
                                radius = ringRadius,
                                center = center,
                                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }

                        // Stereo width indicators
                        val widthOffset = (params.stereoWidth * 40.dp.toPx()).coerceAtMost(w * 0.4f)
                        drawCircle(color = StudioCyan, radius = 5.dp.toPx(), center = Offset(center.x - widthOffset, center.y))
                        drawCircle(color = StudioCyan, radius = 5.dp.toPx(), center = Offset(center.x + widthOffset, center.y))
                    }

                    // Status Overlay
                    Row(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("DECAY: ${String.format(java.util.Locale.US, "%.1fs", params.roomSize)}", color = StudioPurple, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("PRE-DELAY: ${params.preDelayMs.roundToInt()}ms", color = TextSecondary, fontSize = 10.sp)
                        Text("WIDTH: ${(params.stereoWidth * 100).roundToInt()}%", color = StudioCyan, fontSize = 10.sp)
                    }
                }
            }

            // Room Architecture: Room Size & Pre-Delay
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioPurple.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("DIMENSIONES DEL ESPACIO", color = StudioPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.roomSize,
                            onValueChange = { onParamsChange(params.copy(roomSize = it)) },
                            range = 0.2f..10.0f,
                            label = "ROOM SIZE",
                            unit = "s",
                            accentColor = StudioPurple,
                            decimals = 1
                        )
                        RotaryKnob(
                            value = params.preDelayMs,
                            onValueChange = { onParamsChange(params.copy(preDelayMs = it)) },
                            range = 0f..120f,
                            label = "PRE-DELAY",
                            unit = "ms",
                            accentColor = StudioPurple,
                            decimals = 0
                        )
                    }
                }
            }

            // Acoustics: Damping & Diffusion
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("ACÚSTICA & AMORTIGUACIÓN", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.dampingHz,
                            onValueChange = { onParamsChange(params.copy(dampingHz = it)) },
                            range = 1000f..20000f,
                            label = "DAMPING",
                            unit = "Hz",
                            accentColor = StudioGold,
                            decimals = 0
                        )
                        RotaryKnob(
                            value = params.diffusion * 100f,
                            onValueChange = { onParamsChange(params.copy(diffusion = it / 100f)) },
                            range = 0f..100f,
                            label = "DIFFUSION",
                            unit = "%",
                            accentColor = StudioGold,
                            decimals = 0
                        )
                    }
                }
            }

            // Stereo Field & Wet/Dry Mix
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("CAMPO ESTÉREO & MEZCLA", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.stereoWidth * 100f,
                            onValueChange = { onParamsChange(params.copy(stereoWidth = it / 100f)) },
                            range = 0f..200f,
                            label = "STEREO WIDTH",
                            unit = "%",
                            accentColor = StudioCyan,
                            decimals = 0
                        )
                        RotaryKnob(
                            value = params.mix * 100f,
                            onValueChange = { onParamsChange(params.copy(mix = it / 100f)) },
                            range = 0f..100f,
                            label = "DRY / WET",
                            unit = "%",
                            accentColor = StudioEmerald,
                            decimals = 0
                        )
                    }
                }
            }
        }
    }
}
