package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.MasterState
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun TimelineTransport(
    masterState: MasterState,
    onTogglePlay: () -> Unit,
    onStop: () -> Unit,
    onToggleRecord: () -> Unit,
    onToggleLoop: () -> Unit,
    onToggleMetronome: () -> Unit,
    onBpmChange: (Int) -> Unit,
    onMasterVolumeChange: (Float) -> Unit,
    onSelectPreset: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showPresetMenu by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(StudioSurface)
            .border(1.dp, StudioBorder)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("timeline_transport")
    ) {
        // Top branding row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Gold Currency Studio Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(StudioGold)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "BD$",
                    color = StudioBackground,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column {
                Text(
                    text = "BD$ STUDIO",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "MOBILE DAW • 44.1kHz DSP",
                    color = StudioCyan,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Project Presets Dropdown
            Box {
                Button(
                    onClick = { showPresetMenu = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioSurfaceVariant,
                        contentColor = TextPrimary
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(34.dp).testTag("btn_presets_menu")
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = "Presets",
                        tint = StudioGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Demos", fontSize = 12.sp)
                }

                DropdownMenu(
                    expanded = showPresetMenu,
                    onDismissRequest = { showPresetMenu = false },
                    modifier = Modifier.background(StudioSurfaceVariant)
                ) {
                    DropdownMenuItem(
                        text = { Text("Latin Trap 808 (130 BPM)", color = TextPrimary) },
                        onClick = {
                            onSelectPreset("Latin Trap 808")
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Cyberpunk Synth (110 BPM)", color = TextPrimary) },
                        onClick = {
                            onSelectPreset("Cyberpunk Synth")
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Lo-Fi Chill (85 BPM)", color = TextPrimary) },
                        onClick = {
                            onSelectPreset("Lo-Fi Chill")
                            showPresetMenu = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Transport Controls Row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Play / Pause Button
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if (masterState.isPlaying) StudioEmerald else StudioGold)
                    .clickable(onClick = onTogglePlay)
                    .testTag("btn_transport_play"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (masterState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (masterState.isPlaying) "Pausar" else "Reproducir",
                    tint = StudioBackground,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Stop Button
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(StudioSurfaceVariant)
                    .clickable(onClick = onStop)
                    .testTag("btn_transport_stop"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Stop,
                    contentDescription = "Detener",
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Record Button
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (masterState.isRecording) StudioCrimson else StudioSurfaceVariant)
                    .clickable(onClick = onToggleRecord)
                    .testTag("btn_transport_record"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.FiberManualRecord,
                    contentDescription = "Grabar",
                    tint = if (masterState.isRecording) Color.White else StudioCrimson,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Loop Toggle
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (masterState.loopEnabled) StudioCyan.copy(alpha = 0.2f) else StudioSurfaceVariant)
                    .border(1.dp, if (masterState.loopEnabled) StudioCyan else StudioBorder, RoundedCornerShape(8.dp))
                    .clickable(onClick = onToggleLoop)
                    .testTag("btn_transport_loop"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Repeat,
                    contentDescription = "Bucle",
                    tint = if (masterState.loopEnabled) StudioCyan else TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Metronome Toggle
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (masterState.metronomeEnabled) StudioGold.copy(alpha = 0.2f) else StudioSurfaceVariant)
                    .border(1.dp, if (masterState.metronomeEnabled) StudioGold else StudioBorder, RoundedCornerShape(8.dp))
                    .clickable(onClick = onToggleMetronome)
                    .testTag("btn_transport_metronome"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AccessTime,
                    contentDescription = "Metrónomo",
                    tint = if (masterState.metronomeEnabled) StudioGold else TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // BPM display & stepper
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "TEMPO",
                    fontSize = 9.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { onBpmChange(masterState.bpm - 1) },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Text("-", color = StudioGold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "${masterState.bpm}",
                        color = StudioGold,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black
                    )

                    IconButton(
                        onClick = { onBpmChange(masterState.bpm + 1) },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Text("+", color = StudioGold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Position & Master VU Meters Row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Bar & Step Readout
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(StudioCard)
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                val stepInBar = (masterState.currentStep % 4) + 1
                Text(
                    text = "BAR ${masterState.currentBar} : $stepInBar",
                    color = StudioEmerald,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Master volume slider & VU meter
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("MASTER VOL", fontSize = 9.sp, color = TextSecondary)
                    Text(
                        text = "${(masterState.volume * 100).roundToInt()}%",
                        fontSize = 10.sp,
                        color = StudioGold,
                        fontWeight = FontWeight.Bold
                    )
                }
                Slider(
                    value = masterState.volume,
                    onValueChange = onMasterVolumeChange,
                    valueRange = 0f..1.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = StudioGold,
                        activeTrackColor = StudioGold,
                        inactiveTrackColor = ControlTrack
                    ),
                    modifier = Modifier.height(20.dp).testTag("slider_master_vol")
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Stereo Master VU
            StereoVUMeter(
                rmsL = masterState.masterRmsLeft,
                rmsR = masterState.masterRmsRight
            )
        }
    }
}
