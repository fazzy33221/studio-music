package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Studio Dark Theme Colors
val StudioBackground = Color(0xFF0C0E14)
val StudioSurface = Color(0xFF141722)
val StudioSurfaceVariant = Color(0xFF1B2030)
val StudioCard = Color(0xFF161A26)
val StudioBorder = Color(0xFF262C40)

// Accent Colors
val StudioGold = Color(0xFFFFC107)
val StudioGoldBright = Color(0xFFFFD54F)
val StudioGoldDark = Color(0xFFC79100)
val StudioCyan = Color(0xFF00E5FF)
val StudioCyanGlow = Color(0xFF80F0FF)
val StudioEmerald = Color(0xFF00E676)
val StudioCrimson = Color(0xFFFF1744)
val StudioOrange = Color(0xFFFF9100)
val StudioPurple = Color(0xFFB388FF)
val StudioBlue = Color(0xFF2979FF)

// VU Meter Colors
val VuGreen = Color(0xFF00E676)
val VuYellow = Color(0xFFFFEA00)
val VuOrange = Color(0xFFFF9100)
val VuRed = Color(0xFFFF1744)

// Text & Control Colors
val TextPrimary = Color(0xFFECEFF1)
val TextSecondary = Color(0xFF90A4AE)
val TextDisabled = Color(0xFF546E7A)
val ControlTrack = Color(0xFF202636)
val ControlThumb = Color(0xFFFFC107)
