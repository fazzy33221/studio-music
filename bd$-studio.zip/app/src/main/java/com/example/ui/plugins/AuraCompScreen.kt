package com.example.ui.plugins

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AuraCompParams
import com.example.ui.components.RotaryKnob
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun AuraCompScreen(
    trackName: String,
    isEnabled: Boolean,
    params: AuraCompParams,
    gainReduction: Float,
    onParamsChange: (AuraCompParams) -> Unit,
    onToggleBypass: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var showPresetMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("screen_aura_comp")
    ) {
        // Top Header Bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurface)
                .border(1.dp, StudioBorder)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("btn_back_from_comp")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Volver a BD$ Studio",
                    tint = StudioCyan
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "AuraComp",
                        color = StudioCyan,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(StudioCyan.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "VCA DYNAMICS",
                            color = StudioCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = "Pista: $trackName",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            // Presets Dropdown
            Box {
                Button(
                    onClick = { showPresetMenu = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioSurfaceVariant,
                        contentColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp).testTag("btn_comp_presets")
                ) {
                    Text("Presets", fontSize = 11.sp)
                }

                DropdownMenu(
                    expanded = showPresetMenu,
                    onDismissRequest = { showPresetMenu = false },
                    modifier = Modifier.background(StudioSurfaceVariant)
                ) {
                    DropdownMenuItem(
                        text = { Text("Glue Bus (2:1 Gentle)", color = TextPrimary) },
                        onClick = {
                            onParamsChange(AuraCompParams(thresholdDb = -12f, ratio = 2f, attackMs = 30f, releaseMs = 150f, makeupGainDb = 2f))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Drum Slam (6:1 Punchy)", color = TextPrimary) },
                        onClick = {
                            onParamsChange(AuraCompParams(thresholdDb = -20f, ratio = 6f, attackMs = 5f, releaseMs = 80f, makeupGainDb = 5f))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Vocal Leveller (4:1)", color = TextPrimary) },
                        onClick = {
                            onParamsChange(AuraCompParams(thresholdDb = -18f, ratio = 4f, attackMs = 12f, releaseMs = 180f, makeupGainDb = 4f))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Limiting / Brickwall (12:1)", color = TextPrimary) },
                        onClick = {
                            onParamsChange(AuraCompParams(thresholdDb = -10f, ratio = 12f, attackMs = 1f, releaseMs = 50f, makeupGainDb = 3f))
                            showPresetMenu = false
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Bypass Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isEnabled) StudioEmerald else StudioCrimson)
                    .clickable(onClick = onToggleBypass)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("btn_toggle_comp_bypass"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isEnabled) "ON" else "BYPASS",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Visual Gain Reduction Meter & Transfer Curve Card
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth().height(160.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Gain Reduction (GR) Meter
                    Column(
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "GAIN REDUCTION",
                            fontSize = 10.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "-${String.format(java.util.Locale.US, "%.1f", gainReduction.coerceAtLeast(0f))} dB",
                            fontSize = 13.sp,
                            color = StudioCrimson,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(4.dp))

                        // GR Bar
                        Canvas(modifier = Modifier.fillMaxWidth().weight(1f)) {
                            val w = size.width
                            val h = size.height
                            val maxGr = 20f
                            val normGr = (gainReduction / maxGr).coerceIn(0f, 1f)

                            // Background track
                            drawRect(color = StudioBorder, topLeft = Offset(0f, 0f), size = size)

                            // Active reduction filling from top
                            val grHeight = normGr * h
                            drawRect(
                                color = StudioCrimson,
                                topLeft = Offset(0f, 0f),
                                size = androidx.compose.ui.geometry.Size(w, grHeight)
                            )
                        }
                    }

                    // Compression Transfer Curve Canvas
                    Column(
                        modifier = Modifier.weight(1.8f).fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "TRANSFER CURVE (dB In vs Out)",
                            fontSize = 10.sp,
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw diagonal unity reference line (dashed / faint)
                            drawLine(
                                color = StudioBorder,
                                start = Offset(0f, h),
                                end = Offset(w, 0f),
                                strokeWidth = 1.dp.toPx()
                            )

                            // Draw compressed response curve
                            val path = Path()
                            val threshNorm = ((params.thresholdDb + 60f) / 60f).coerceIn(0f, 1f)
                            val threshX = threshNorm * w
                            val threshY = (1f - threshNorm) * h

                            // Before threshold (1:1 slope)
                            path.moveTo(0f, h)
                            path.lineTo(threshX, threshY)

                            // After threshold (compressed slope = 1 / ratio)
                            val endX = w
                            val slope = 1f / params.ratio
                            val endNormY = threshNorm + (1f - threshNorm) * slope
                            val endY = (1f - endNormY) * h

                            path.lineTo(endX, endY)

                            drawPath(
                                path = path,
                                color = StudioCyan,
                                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                            )

                            // Threshold Knee Node
                            drawCircle(color = StudioGold, radius = 5.dp.toPx(), center = Offset(threshX, threshY))
                        }
                    }
                }
            }

            // Dynamics Section: Threshold, Ratio, Knee
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioCyan.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("DYNAMICS & THRESHOLD", color = StudioCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.thresholdDb,
                            onValueChange = { onParamsChange(params.copy(thresholdDb = it)) },
                            range = -60f..0f,
                            label = "THRESHOLD",
                            unit = "dB",
                            accentColor = StudioCyan,
                            decimals = 1
                        )
                        RotaryKnob(
                            value = params.ratio,
                            onValueChange = { onParamsChange(params.copy(ratio = it)) },
                            range = 1f..20f,
                            label = "RATIO",
                            unit = ":1",
                            accentColor = StudioCyan,
                            decimals = 1
                        )
                        RotaryKnob(
                            value = params.kneeDb,
                            onValueChange = { onParamsChange(params.copy(kneeDb = it)) },
                            range = 0f..12f,
                            label = "KNEE",
                            unit = "dB",
                            accentColor = StudioCyan,
                            decimals = 1
                        )
                    }
                }
            }

            // Time Constants: Attack & Release
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("ENVELOPE TIME CONSTANTS", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.attackMs,
                            onValueChange = { onParamsChange(params.copy(attackMs = it)) },
                            range = 0.1f..100f,
                            label = "ATTACK",
                            unit = "ms",
                            accentColor = StudioGold,
                            decimals = 1
                        )
                        RotaryKnob(
                            value = params.releaseMs,
                            onValueChange = { onParamsChange(params.copy(releaseMs = it)) },
                            range = 10f..1000f,
                            label = "RELEASE",
                            unit = "ms",
                            accentColor = StudioGold,
                            decimals = 0
                        )
                    }
                }
            }

            // Output & Parallel Processing: Makeup Gain & Dry/Wet Mix
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("OUTPUT & PARALLEL MIX", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.makeupGainDb,
                            onValueChange = { onParamsChange(params.copy(makeupGainDb = it)) },
                            range = 0f..24f,
                            label = "MAKEUP",
                            unit = "dB",
                            accentColor = StudioEmerald,
                            decimals = 1
                        )
                        RotaryKnob(
                            value = params.mix * 100f,
                            onValueChange = { onParamsChange(params.copy(mix = it / 100f)) },
                            range = 0f..100f,
                            label = "DRY / WET",
                            unit = "%",
                            accentColor = StudioEmerald,
                            decimals = 0
                        )
                    }
                }
            }
        }
    }
}
