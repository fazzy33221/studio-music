package com.example.ui.plugins

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.EQ3ChiParams
import com.example.ui.components.RotaryKnob
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun EQ3ChiScreen(
    trackName: String,
    isEnabled: Boolean,
    params: EQ3ChiParams,
    onParamsChange: (EQ3ChiParams) -> Unit,
    onToggleBypass: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var showPresetMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("screen_eq_3chi")
    ) {
        // Plugin Top Header Bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurface)
                .border(1.dp, StudioBorder)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("btn_back_from_eq")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Volver a BD$ Studio",
                    tint = StudioGold
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "EQ 3CHI",
                        color = StudioGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(StudioGold.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "3-BAND CHI MASTER",
                            color = StudioGold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = "Pista: $trackName",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            // Presets Dropdown
            Box {
                Button(
                    onClick = { showPresetMenu = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioSurfaceVariant,
                        contentColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp).testTag("btn_eq_presets")
                ) {
                    Text("Presets", fontSize = 11.sp)
                }

                DropdownMenu(
                    expanded = showPresetMenu,
                    onDismissRequest = { showPresetMenu = false },
                    modifier = Modifier.background(StudioSurfaceVariant)
                ) {
                    DropdownMenuItem(
                        text = { Text("Flat / Reset", color = TextPrimary) },
                        onClick = {
                            onParamsChange(EQ3ChiParams())
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Vocal Air & Warmth", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(chi1Gain = -2f, chi2Gain = 1.5f, chi3Gain = 4.5f, chi3Freq = 10000f, warmthDrive = 0.25f))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("808 Sub Punch", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(chi1Gain = 5.0f, chi1Freq = 65f, chi2Gain = -3f, chi3Gain = 1f, warmthDrive = 0.35f))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Snappy Snare / Claps", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(chi1Gain = -1f, chi2Gain = 4.0f, chi2Freq = 2400f, chi3Gain = 3.0f))
                            showPresetMenu = false
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Bypass Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isEnabled) StudioEmerald else StudioCrimson)
                    .clickable(onClick = onToggleBypass)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("btn_toggle_eq_bypass"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isEnabled) "ON" else "BYPASS",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Interactive Frequency Response Curve
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth().height(160.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val midY = h / 2f

                        // Draw Grid lines
                        val freqs = listOf(100f, 1000f, 10000f)
                        val labels = listOf("100Hz", "1kHz", "10kHz")
                        val minF = 20f
                        val maxF = 20000f

                        freqs.forEachIndexed { idx, f ->
                            val normX = (log10(f / minF) / log10(maxF / minF)).coerceIn(0f, 1f)
                            val x = normX * w
                            drawLine(
                                color = StudioBorder,
                                start = Offset(x, 0f),
                                end = Offset(x, h),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        // 0 dB center reference line
                        drawLine(
                            color = StudioBorder.copy(alpha = 0.8f),
                            start = Offset(0f, midY),
                            end = Offset(w, midY),
                            strokeWidth = 1.dp.toPx()
                        )

                        // Calculate Frequency response curve
                        val path = Path()
                        val pointsCount = 100
                        for (i in 0..pointsCount) {
                            val normX = i.toFloat() / pointsCount
                            val currentFreq = minF * (maxF / minF).pow(normX)

                            // Approximate combined dB response of the 3 CHI bands
                            val g1 = computeBandResponse(currentFreq, params.chi1Freq, params.chi1Gain, params.chi1Q)
                            val g2 = computeBandResponse(currentFreq, params.chi2Freq, params.chi2Gain, params.chi2Q)
                            val g3 = computeBandResponse(currentFreq, params.chi3Freq, params.chi3Gain, params.chi3Q)
                            val totalGainDb = (g1 + g2 + g3 + params.outputTrim).coerceIn(-15f, 15f)

                            val y = midY - (totalGainDb / 15f) * (midY * 0.85f)
                            val x = normX * w

                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }

                        // Draw glow line
                        drawPath(
                            path = path,
                            color = StudioGold,
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Draw 3 CHI Nodes
                        val bands = listOf(
                            Triple(params.chi1Freq, params.chi1Gain, StudioGold),
                            Triple(params.chi2Freq, params.chi2Gain, StudioOrange),
                            Triple(params.chi3Freq, params.chi3Gain, StudioCyan)
                        )

                        bands.forEach { (freq, gain, col) ->
                            val normX = (log10(freq / minF) / log10(maxF / minF)).coerceIn(0f, 1f)
                            val x = normX * w
                            val y = midY - (gain.coerceIn(-15f, 15f) / 15f) * (midY * 0.85f)

                            drawCircle(color = col, radius = 6.dp.toPx(), center = Offset(x, y))
                            drawCircle(color = StudioBackground, radius = 3.dp.toPx(), center = Offset(x, y))
                        }
                    }

                    // Legend
                    Row(
                        modifier = Modifier.align(Alignment.TopEnd).padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("● CHI 1 (Low)", color = StudioGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("● CHI 2 (Mid)", color = StudioOrange, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("● CHI 3 (High)", color = StudioCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // CHI 1 (Low / Tierra) Card
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioGold.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(10.dp).background(StudioGold, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("CHI 1 — TIERRA (LOW BAND)", color = StudioGold, fontSize = 13.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.chi1Freq,
                            onValueChange = { onParamsChange(params.copy(chi1Freq = it)) },
                            range = 20f..500f,
                            label = "FREQ",
                            unit = "Hz",
                            accentColor = StudioGold,
                            decimals = 0
                        )
                        RotaryKnob(
                            value = params.chi1Gain,
                            onValueChange = { onParamsChange(params.copy(chi1Gain = it)) },
                            range = -15f..15f,
                            label = "GAIN",
                            unit = "dB",
                            accentColor = StudioGold,
                            decimals = 1
                        )
                        RotaryKnob(
                            value = params.chi1Q,
                            onValueChange = { onParamsChange(params.copy(chi1Q = it)) },
                            range = 0.3f..5.0f,
                            label = "Q / WIDTH",
                            unit = "Q",
                            accentColor = StudioGold,
                            decimals = 2
                        )
                    }
                }
            }

            // CHI 2 (Mid / Fuego) Card
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioOrange.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(10.dp).background(StudioOrange, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("CHI 2 — FUEGO (MID BAND)", color = StudioOrange, fontSize = 13.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.chi2Freq,
                            onValueChange = { onParamsChange(params.copy(chi2Freq = it)) },
                            range = 200f..6000f,
                            label = "FREQ",
                            unit = "Hz",
                            accentColor = StudioOrange,
                            decimals = 0
                        )
                        RotaryKnob(
                            value = params.chi2Gain,
                            onValueChange = { onParamsChange(params.copy(chi2Gain = it)) },
                            range = -15f..15f,
                            label = "GAIN",
                            unit = "dB",
                            accentColor = StudioOrange,
                            decimals = 1
                        )
                        RotaryKnob(
                            value = params.chi2Q,
                            onValueChange = { onParamsChange(params.copy(chi2Q = it)) },
                            range = 0.3f..5.0f,
                            label = "Q / WIDTH",
                            unit = "Q",
                            accentColor = StudioOrange,
                            decimals = 2
                        )
                    }
                }
            }

            // CHI 3 (High / Aire) Card
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioCyan.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(10.dp).background(StudioCyan, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("CHI 3 — AIRE (HIGH BAND)", color = StudioCyan, fontSize = 13.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.chi3Freq,
                            onValueChange = { onParamsChange(params.copy(chi3Freq = it)) },
                            range = 2000f..20000f,
                            label = "FREQ",
                            unit = "Hz",
                            accentColor = StudioCyan,
                            decimals = 0
                        )
                        RotaryKnob(
                            value = params.chi3Gain,
                            onValueChange = { onParamsChange(params.copy(chi3Gain = it)) },
                            range = -15f..15f,
                            label = "GAIN",
                            unit = "dB",
                            accentColor = StudioCyan,
                            decimals = 1
                        )
                        RotaryKnob(
                            value = params.chi3Q,
                            onValueChange = { onParamsChange(params.copy(chi3Q = it)) },
                            range = 0.3f..5.0f,
                            label = "Q / WIDTH",
                            unit = "Q",
                            accentColor = StudioCyan,
                            decimals = 2
                        )
                    }
                }
            }

            // Master Section: Warmth Drive & Output Trim
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("MASTER STAGE & ANALOG DRIVE", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.warmthDrive * 100f,
                            onValueChange = { onParamsChange(params.copy(warmthDrive = it / 100f)) },
                            range = 0f..100f,
                            label = "WARMTH",
                            unit = "%",
                            accentColor = StudioGoldBright,
                            decimals = 0
                        )
                        RotaryKnob(
                            value = params.outputTrim,
                            onValueChange = { onParamsChange(params.copy(outputTrim = it)) },
                            range = -12f..12f,
                            label = "OUTPUT TRIM",
                            unit = "dB",
                            accentColor = TextPrimary,
                            decimals = 1
                        )
                    }
                }
            }
        }
    }
}

// Helper to compute bell gain contribution
private fun computeBandResponse(freq: Float, centerFreq: Float, gainDb: Float, q: Float): Float {
    if (abs(gainDb) < 0.05f) return 0f
    val octaves = abs(log2(freq / centerFreq))
    val bandwidth = 1f / q.coerceAtLeast(0.1f)
    val factor = exp(-0.5f * (octaves / (bandwidth * 0.5f)).pow(2))
    return gainDb * factor
}
