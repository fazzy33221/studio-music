package com.example.ui.plugins

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AuraMaximizerParams
import com.example.ui.components.RotaryKnob
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun AuraMaximizerScreen(
    trackName: String,
    isEnabled: Boolean,
    params: AuraMaximizerParams,
    onParamsChange: (AuraMaximizerParams) -> Unit,
    onToggleBypass: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var showPresetMenu by remember { mutableStateOf(false) }

    // Waveform crest animation
    val infiniteTransition = rememberInfiniteTransition(label = "MaximizerAnim")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("screen_aura_maximizer")
    ) {
        // Top Header Bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(StudioSurface)
                .border(1.dp, StudioBorder)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("btn_back_from_maximizer")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Volver a BD$ Studio",
                    tint = StudioOrange
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "AuraMaximizer",
                        color = StudioOrange,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(StudioOrange.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "BRICKWALL LIMITER",
                            color = StudioOrange,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = "Pista: $trackName",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            // Presets Dropdown
            Box {
                Button(
                    onClick = { showPresetMenu = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioSurfaceVariant,
                        contentColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp).testTag("btn_maximizer_presets")
                ) {
                    Text("Presets", fontSize = 11.sp)
                }

                DropdownMenu(
                    expanded = showPresetMenu,
                    onDismissRequest = { showPresetMenu = false },
                    modifier = Modifier.background(StudioSurfaceVariant)
                ) {
                    DropdownMenuItem(
                        text = { Text("Streaming Target (-14 LUFS)", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(driveDb = 3.5f, ceilingDb = -1.0f, releaseMs = 80f, transientPunch = 0.3f, character = "Clean"))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Club Heavy Banger (-8 LUFS)", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(driveDb = 9.0f, ceilingDb = -0.3f, releaseMs = 45f, transientPunch = 0.7f, character = "Punchy"))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Warm Tape Master", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(driveDb = 5.0f, ceilingDb = -0.5f, releaseMs = 120f, transientPunch = 0.4f, character = "Warm"))
                            showPresetMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Crisp Modern Pop", color = TextPrimary) },
                        onClick = {
                            onParamsChange(params.copy(driveDb = 6.5f, ceilingDb = -0.2f, releaseMs = 50f, transientPunch = 0.5f, character = "Clean"))
                            showPresetMenu = false
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Bypass Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isEnabled) StudioEmerald else StudioCrimson)
                    .clickable(onClick = onToggleBypass)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("btn_toggle_maximizer_bypass"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isEnabled) "ON" else "BYPASS",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Loudness Metering Readout Card
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("TRUE PEAK", fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${String.format(java.util.Locale.US, "%.1f", params.ceilingDb)} dBTP",
                            fontSize = 15.sp,
                            color = StudioGold,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Box(modifier = Modifier.width(1.dp).height(30.dp).background(StudioBorder))

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ESTIMATED LOUDNESS", fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                        val estimatedLufs = -18f + params.driveDb * 1.2f
                        Text(
                            text = "${String.format(java.util.Locale.US, "%.1f", estimatedLufs.coerceIn(-24f, -4f))} LUFS",
                            fontSize = 15.sp,
                            color = if (estimatedLufs > -9f) VuRed else StudioEmerald,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Box(modifier = Modifier.width(1.dp).height(30.dp).background(StudioBorder))

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("GAIN BOOST", fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                        Text(
                            text = "+${String.format(java.util.Locale.US, "%.1f", params.driveDb)} dB",
                            fontSize = 15.sp,
                            color = StudioOrange,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            // Real-time Crest Waveform & Brickwall Ceiling Clamping Canvas
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioOrange.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth().height(160.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().padding(10.dp)) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val midY = h / 2f

                        // Ceiling clamp line
                        val ceilingNorm = (params.ceilingDb.coerceIn(-6f, 0f) / -6f).coerceIn(0f, 1f)
                        val ceilingOffset = (h * 0.1f) + ceilingNorm * (h * 0.25f)
                        val topCeilingY = ceilingOffset
                        val bottomCeilingY = h - ceilingOffset

                        // Draw ceiling lines
                        drawLine(
                            color = StudioOrange,
                            start = Offset(0f, topCeilingY),
                            end = Offset(w, topCeilingY),
                            strokeWidth = 1.5.dp.toPx()
                        )
                        drawLine(
                            color = StudioOrange,
                            start = Offset(0f, bottomCeilingY),
                            end = Offset(w, bottomCeilingY),
                            strokeWidth = 1.5.dp.toPx()
                        )

                        // Center 0 line
                        drawLine(
                            color = StudioBorder,
                            start = Offset(0f, midY),
                            end = Offset(w, midY),
                            strokeWidth = 1.dp.toPx()
                        )

                        // Draw maximized waveform
                        val path = Path()
                        val points = 80
                        val driveMultiplier = 1f + (params.driveDb / 18f) * 2.5f

                        for (i in 0..points) {
                            val normX = i.toFloat() / points
                            val x = normX * w
                            val t = normX * 8f * PI.toFloat() + phase

                            // Multi-tone waveform
                            var rawSample = (sin(t) * 0.6f + sin(t * 2.2f) * 0.3f + sin(t * 0.5f) * 0.2f) * driveMultiplier

                            // Soft-knee brickwall limiting
                            val maxAmp = (midY - ceilingOffset) / midY
                            val clampedSample = tanh(rawSample).coerceIn(-maxAmp, maxAmp)
                            val y = midY - clampedSample * (midY * 0.95f)

                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }

                        drawPath(
                            path = path,
                            color = StudioGold,
                            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    // Ceiling label
                    Text(
                        text = "CEILING: ${String.format(java.util.Locale.US, "%.1f", params.ceilingDb)} dB",
                        color = StudioOrange,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.TopEnd)
                    )
                }
            }

            // Character Color Selector
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("CARÁCTER / SATURACIÓN ARMÓNICA", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    val characters = listOf("Clean", "Punchy", "Warm", "Analog")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        characters.forEach { charName ->
                            val isSelected = params.character == charName
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) StudioOrange else StudioSurfaceVariant)
                                    .clickable { onParamsChange(params.copy(character = charName)) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = charName,
                                    color = if (isSelected) StudioBackground else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Drive & Ceiling Primary Knobs
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioOrange.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("DRIVE & MARGEN DE SALIDA", color = StudioOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.driveDb,
                            onValueChange = { onParamsChange(params.copy(driveDb = it)) },
                            range = 0f..18f,
                            label = "DRIVE / BOOST",
                            unit = "dB",
                            accentColor = StudioOrange,
                            decimals = 1
                        )
                        RotaryKnob(
                            value = params.ceilingDb,
                            onValueChange = { onParamsChange(params.copy(ceilingDb = it)) },
                            range = -6.0f..-0.1f,
                            label = "CEILING",
                            unit = "dB",
                            accentColor = StudioGold,
                            decimals = 1
                        )
                    }
                }
            }

            // Speed & Transient Punch
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("TRANSIENTES & RESPUESTA", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        RotaryKnob(
                            value = params.transientPunch * 100f,
                            onValueChange = { onParamsChange(params.copy(transientPunch = it / 100f)) },
                            range = 0f..100f,
                            label = "TRANSIENT PUNCH",
                            unit = "%",
                            accentColor = StudioCyan,
                            decimals = 0
                        )
                        RotaryKnob(
                            value = params.releaseMs,
                            onValueChange = { onParamsChange(params.copy(releaseMs = it)) },
                            range = 10f..500f,
                            label = "RELEASE",
                            unit = "ms",
                            accentColor = StudioGold,
                            decimals = 0
                        )
                    }
                }
            }
        }
    }
}
