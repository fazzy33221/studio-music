package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.EffectType
import com.example.ui.theme.*

@Composable
fun AddEffectDialog(
    trackName: String,
    onEffectSelected: (EffectType) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("add_effect_dialog"),
        containerColor = StudioSurface,
        title = {
            Column {
                Text(
                    text = "AGREGAR EFX",
                    color = StudioGold,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Pista: $trackName",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                EffectOptionCard(
                    title = "1. EQ 3CHI",
                    subtitle = "Ecualizador analógico de 3 bandas CHI con curva interactiva",
                    badgeColor = StudioGold,
                    icon = Icons.Default.GraphicEq,
                    onClick = {
                        onEffectSelected(EffectType.EQ_3CHI)
                        onDismiss()
                    }
                )

                EffectOptionCard(
                    title = "2. AuraComp",
                    subtitle = "Compresor de estudio VCA con medidor VU y Gain Reduction",
                    badgeColor = StudioCyan,
                    icon = Icons.Default.Compress,
                    onClick = {
                        onEffectSelected(EffectType.AURA_COMP)
                        onDismiss()
                    }
                )

                EffectOptionCard(
                    title = "3. AuraSpace",
                    subtitle = "Reverb y procesador espacial 3D con visualizador acústico",
                    badgeColor = StudioPurple,
                    icon = Icons.Default.SurroundSound,
                    onClick = {
                        onEffectSelected(EffectType.AURA_SPACE)
                        onDismiss()
                    }
                )

                EffectOptionCard(
                    title = "4. AuraMaximizer",
                    subtitle = "Maximizador de volumen y limitador brickwall de mastering",
                    badgeColor = StudioOrange,
                    icon = Icons.Default.Speed,
                    onClick = {
                        onEffectSelected(EffectType.AURA_MAXIMIZER)
                        onDismiss()
                    }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_cancel_efx")
            ) {
                Text("Cancelar", color = TextSecondary)
            }
        }
    )
}

@Composable
private fun EffectOptionCard(
    title: String,
    subtitle: String,
    badgeColor: Color,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceVariant),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag("btn_select_${title.replace(" ", "_")}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(badgeColor.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = badgeColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 15.sp
                )
            }

            Icon(
                imageVector = Icons.Default.AddCircleOutline,
                contentDescription = "Agregar",
                tint = badgeColor,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
