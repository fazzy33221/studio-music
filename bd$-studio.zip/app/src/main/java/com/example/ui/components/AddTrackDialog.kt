package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.InstrumentType
import com.example.ui.theme.*

@Composable
fun AddTrackDialog(
    onTrackAdded: (InstrumentType, String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedType by remember { mutableStateOf(InstrumentType.DRUMS) }
    var trackName by remember { mutableStateOf(selectedType.displayName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("add_track_dialog"),
        containerColor = StudioSurface,
        title = {
            Text(
                text = "NUEVA PISTA",
                color = StudioGold,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = trackName,
                    onValueChange = { trackName = it },
                    label = { Text("Nombre de la pista") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = StudioGold,
                        unfocusedBorderColor = StudioBorder,
                        focusedLabelColor = StudioGold,
                        unfocusedLabelColor = TextSecondary
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_track_name")
                )

                Text(
                    text = "Tipo de Instrumento / Sonido:",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                InstrumentType.values().forEach { type ->
                    val isSelected = selectedType == type
                    val icon: ImageVector = when (type) {
                        InstrumentType.DRUMS -> Icons.Default.MusicNote
                        InstrumentType.BASS -> Icons.Default.GraphicEq
                        InstrumentType.SYNTH_LEAD -> Icons.Default.Piano
                        InstrumentType.KEYS -> Icons.Default.Keyboard
                        InstrumentType.HI_HATS -> Icons.Default.Grain
                        InstrumentType.AUDIO_VOCAL -> Icons.Default.Mic
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) StudioSurfaceVariant else StudioCard)
                            .clickable {
                                selectedType = type
                                trackName = type.displayName
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = {
                                selectedType = type
                                trackName = type.displayName
                            },
                            colors = RadioButtonDefaults.colors(selectedColor = StudioGold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = icon,
                            contentDescription = type.displayName,
                            tint = if (isSelected) StudioGold else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = type.displayName,
                            color = if (isSelected) StudioGold else TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onTrackAdded(selectedType, trackName.ifBlank { selectedType.displayName })
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = StudioGold, contentColor = StudioBackground),
                modifier = Modifier.testTag("btn_confirm_add_track")
            ) {
                Text("Crear Pista", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TextSecondary)
            }
        }
    )
}
