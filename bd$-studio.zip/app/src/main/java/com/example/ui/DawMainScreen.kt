package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.EffectType
import com.example.ui.components.*
import com.example.ui.plugins.*
import com.example.ui.theme.*
import com.example.viewmodel.DawViewModel

@Composable
fun DawMainScreen(viewModel: DawViewModel) {
    val tracks by viewModel.tracks.collectAsStateWithLifecycle()
    val masterState by viewModel.masterState.collectAsStateWithLifecycle()
    val activeTrackId by viewModel.activeEffectTrackId.collectAsStateWithLifecycle()
    val activeEffectId by viewModel.activeEffectId.collectAsStateWithLifecycle()

    var showAddTrackDialog by remember { mutableStateOf(false) }
    var trackIdForAddEffect by remember { mutableStateOf<String?>(null) }

    // If an effect is open, display ITS DEDICATED INTERFACE!
    if (activeTrackId != null && activeEffectId != null) {
        val currentTrack = tracks.find { it.id == activeTrackId }
        val currentEffect = currentTrack?.effects?.find { it.id == activeEffectId }

        if (currentTrack != null && currentEffect != null) {
            when (currentEffect.type) {
                EffectType.EQ_3CHI -> {
                    EQ3ChiScreen(
                        trackName = currentTrack.name,
                        isEnabled = currentEffect.isEnabled,
                        params = currentEffect.eqParams,
                        onParamsChange = { newParams ->
                            viewModel.updateEQ3ChiParams(currentTrack.id, currentEffect.id, newParams)
                        },
                        onToggleBypass = {
                            viewModel.toggleEffectBypass(currentTrack.id, currentEffect.id)
                        },
                        onBack = {
                            viewModel.closeEffectScreen()
                        }
                    )
                    return
                }

                EffectType.AURA_COMP -> {
                    AuraCompScreen(
                        trackName = currentTrack.name,
                        isEnabled = currentEffect.isEnabled,
                        params = currentEffect.compParams,
                        gainReduction = masterState.gainReductionComp,
                        onParamsChange = { newParams ->
                            viewModel.updateAuraCompParams(currentTrack.id, currentEffect.id, newParams)
                        },
                        onToggleBypass = {
                            viewModel.toggleEffectBypass(currentTrack.id, currentEffect.id)
                        },
                        onBack = {
                            viewModel.closeEffectScreen()
                        }
                    )
                    return
                }

                EffectType.AURA_SPACE -> {
                    AuraSpaceScreen(
                        trackName = currentTrack.name,
                        isEnabled = currentEffect.isEnabled,
                        params = currentEffect.spaceParams,
                        onParamsChange = { newParams ->
                            viewModel.updateAuraSpaceParams(currentTrack.id, currentEffect.id, newParams)
                        },
                        onToggleBypass = {
                            viewModel.toggleEffectBypass(currentTrack.id, currentEffect.id)
                        },
                        onBack = {
                            viewModel.closeEffectScreen()
                        }
                    )
                    return
                }

                EffectType.AURA_MAXIMIZER -> {
                    AuraMaximizerScreen(
                        trackName = currentTrack.name,
                        isEnabled = currentEffect.isEnabled,
                        params = currentEffect.maximizerParams,
                        onParamsChange = { newParams ->
                            viewModel.updateAuraMaximizerParams(currentTrack.id, currentEffect.id, newParams)
                        },
                        onToggleBypass = {
                            viewModel.toggleEffectBypass(currentTrack.id, currentEffect.id)
                        },
                        onBack = {
                            viewModel.closeEffectScreen()
                        }
                    )
                    return
                }
            }
        }
    }

    // MAIN MULTITRACK DAW SCREEN
    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .statusBarsPadding()
            .navigationBarsPadding(),
        topBar = {
            TimelineTransport(
                masterState = masterState,
                onTogglePlay = { viewModel.togglePlay() },
                onStop = { viewModel.stop() },
                onToggleRecord = { viewModel.toggleRecord() },
                onToggleLoop = { viewModel.toggleLoop() },
                onToggleMetronome = { viewModel.toggleMetronome() },
                onBpmChange = { viewModel.setBpm(it) },
                onMasterVolumeChange = { viewModel.setMasterVolume(it) },
                onSelectPreset = { viewModel.loadPreset(it) }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddTrackDialog = true },
                containerColor = StudioGold,
                contentColor = StudioBackground,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("fab_add_track")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Agregar Pista",
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("NUEVA PISTA", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        },
        containerColor = StudioBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Multitrack List Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "PISTAS DEL PROYECTO (${tracks.size})",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.weight(1f))

                Button(
                    onClick = { showAddTrackDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudioSurfaceVariant,
                        contentColor = StudioGold
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp).testTag("btn_header_add_track")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Agregar Pista",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Pista", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tracks List
            if (tracks.isNotEmpty()) {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    modifier = Modifier.fillMaxSize().testTag("tracks_list")
                ) {
                    items(tracks, key = { it.id }) { track ->
                        TrackCard(
                            track = track,
                            currentStep = masterState.currentStep,
                            isPlaying = masterState.isPlaying,
                            onVolumeChange = { viewModel.updateTrackVolume(track.id, it) },
                            onPanChange = { viewModel.updateTrackPan(track.id, it) },
                            onToggleMute = { viewModel.toggleTrackMute(track.id) },
                            onToggleSolo = { viewModel.toggleTrackSolo(track.id) },
                            onToggleStep = { viewModel.toggleStep(track.id, it) },
                            onPreviewTrack = { viewModel.previewTrack(track.id) },
                            onDeleteTrack = { viewModel.deleteTrack(track.id) },
                            onAddEffectClick = { trackIdForAddEffect = track.id },
                            onOpenEffect = { effectId ->
                                viewModel.openEffect(track.id, effectId)
                            },
                            onToggleEffectBypass = { effectId ->
                                viewModel.toggleEffectBypass(track.id, effectId)
                            },
                            onRemoveEffect = { effectId ->
                                viewModel.removeEffectFromTrack(track.id, effectId)
                            }
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "No hay pistas en el proyecto",
                            color = TextSecondary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { showAddTrackDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioGold, contentColor = StudioBackground)
                        ) {
                            Text("Agregar Primera Pista", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Add Track Dialog
    if (showAddTrackDialog) {
        AddTrackDialog(
            onTrackAdded = { type, name ->
                viewModel.addTrack(type, name)
            },
            onDismiss = { showAddTrackDialog = false }
        )
    }

    // Add Effect Dialog
    trackIdForAddEffect?.let { trId ->
        val tr = tracks.find { it.id == trId }
        AddEffectDialog(
            trackName = tr?.name ?: "Pista",
            onEffectSelected = { effectType ->
                viewModel.addEffectToTrack(trId, effectType)
            },
            onDismiss = { trackIdForAddEffect = null }
        )
    }
}
