package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.*

class AudioEngine {
    private val sampleRate = 44100
    private val channels = 2 // Stereo
    private val bufferSize = AudioTrack.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_OUT_STEREO,
        AudioFormat.ENCODING_PCM_16BIT
    ).coerceAtLeast(4096)

    private var audioTrack: AudioTrack? = null
    private var playbackJob: Job? = null
    private val engineScope = CoroutineScope(Dispatchers.Default)

    // Live state updated by ViewModel
    @Volatile var isPlaying: Boolean = false
    @Volatile var bpm: Int = 128
    @Volatile var masterVolume: Float = 0.85f
    @Volatile var metronomeEnabled: Boolean = false
    @Volatile var loopEnabled: Boolean = true

    // Callbacks for UI updates
    var onStepChanged: ((Int) -> Unit)? = null
    var onMeterUpdate: ((Float, Float, Float, Float) -> Unit)? = null // rmsL, rmsR, peak, compGr

    // Active tracks and effects references
    @Volatile var currentTracks: List<Track> = emptyList()

    // Biquad state holder for EQ 3CHI
    private class BiquadFilter {
        var x1 = 0f; var x2 = 0f; var y1 = 0f; var y2 = 0f
        var b0 = 1f; var b1 = 0f; var b2 = 0f; var a1 = 0f; var a2 = 0f

        fun process(x: Float): Float {
            val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1
            x1 = x
            y2 = y1
            y1 = y
            return if (y.isNaN() || y.isInfinite()) 0f else y
        }

        fun reset() {
            x1 = 0f; x2 = 0f; y1 = 0f; y2 = 0f
        }

        fun updatePeaking(freq: Float, gainDb: Float, q: Float, sRate: Float) {
            val w0 = 2f * PI.toFloat() * freq.coerceIn(20f, 20000f) / sRate
            val alpha = sin(w0) / (2f * q.coerceIn(0.2f, 10f))
            val a = 10f.pow(gainDb / 40f)
            val cosW0 = cos(w0)

            val b0Raw = 1f + alpha * a
            val b1Raw = -2f * cosW0
            val b2Raw = 1f - alpha * a
            val a0Raw = 1f + alpha / a
            val a1Raw = -2f * cosW0
            val a2Raw = 1f - alpha / a

            b0 = b0Raw / a0Raw
            b1 = b1Raw / a0Raw
            b2 = b2Raw / a0Raw
            a1 = a1Raw / a0Raw
            a2 = a2Raw / a0Raw
        }
    }

    // Reverb Delay line
    private class DelayLine(val size: Int) {
        val buffer = FloatArray(size)
        var writeIndex = 0

        fun write(sample: Float) {
            buffer[writeIndex] = sample
            writeIndex = (writeIndex + 1) % size
        }

        fun read(delaySamples: Int): Float {
            var readIndex = writeIndex - delaySamples
            while (readIndex < 0) readIndex += size
            return buffer[readIndex % size]
        }
    }

    // State per track for effects
    private class TrackDspState {
        val eqBandsL = Array(3) { BiquadFilter() }
        val eqBandsR = Array(3) { BiquadFilter() }
        var compEnvelope = 0f
        var compGainReduction = 0f
        val revDelaysL = arrayOf(DelayLine(1600), DelayLine(2100), DelayLine(2700), DelayLine(3300))
        val revDelaysR = arrayOf(DelayLine(1750), DelayLine(2250), DelayLine(2850), DelayLine(3450))
        var revDampL = 0f
        var revDampR = 0f
        var maxEnvelope = 0f
    }

    private val trackStates = mutableMapOf<String, TrackDspState>()

    // Instrument Synthesizers
    private class Voice(
        val type: InstrumentType,
        val notePitchHz: Float,
        var samplePos: Int = 0,
        val durationSamples: Int,
        var active: Boolean = true
    )

    private val activeVoices = mutableListOf<Voice>()

    init {
        initAudioTrack()
    }

    private fun initAudioTrack() {
        try {
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun start() {
        if (playbackJob?.isActive == true) return
        isPlaying = true
        if (audioTrack == null || audioTrack?.state != AudioTrack.STATE_INITIALIZED) {
            initAudioTrack()
        }

        playbackJob = engineScope.launch {
            val chunkFrames = 512
            val shortBuffer = ShortArray(chunkFrames * 2) // Stereo
            val floatBufferL = FloatArray(chunkFrames)
            val floatBufferR = FloatArray(chunkFrames)

            var stepSampleCounter = 0
            var currentStep = 0

            var meterTicker = 0

            while (isActive) {
                if (!isPlaying) {
                    // Output silence when stopped
                    shortBuffer.fill(0)
                    audioTrack?.write(shortBuffer, 0, shortBuffer.size)
                    onMeterUpdate?.invoke(0f, 0f, 0f, 0f)
                    kotlinx.coroutines.delay(20)
                    continue
                }

                val samplesPerStep = ((60f / bpm.coerceAtLeast(40)) * sampleRate / 4f).toInt()

                // Clear chunk buffers
                floatBufferL.fill(0f)
                floatBufferR.fill(0f)

                val tracks = currentTracks
                val hasSolo = tracks.any { it.isSolo }

                for (frame in 0 until chunkFrames) {
                    // Check step boundary
                    if (stepSampleCounter >= samplesPerStep) {
                        stepSampleCounter = 0
                        currentStep = (currentStep + 1) % 16
                        onStepChanged?.invoke(currentStep)

                        // Trigger voices for active tracks on this step
                        for (track in tracks) {
                            val isAudible = if (hasSolo) track.isSolo else !track.isMuted
                            if (isAudible && track.steps.getOrElse(currentStep) { false }) {
                                triggerTrackSound(track)
                            }
                        }

                        // Metronome click on quarter beats (steps 0, 4, 8, 12)
                        if (metronomeEnabled && currentStep % 4 == 0) {
                            val clickFreq = if (currentStep == 0) 1400f else 900f
                            synchronized(activeVoices) {
                                activeVoices.add(
                                    Voice(
                                        type = InstrumentType.DRUMS,
                                        notePitchHz = clickFreq,
                                        durationSamples = (sampleRate * 0.04f).toInt()
                                    )
                                )
                            }
                        }
                    }
                    stepSampleCounter++
                }

                // Render active voices into track buffers and apply track effects
                renderTracksAudio(tracks, hasSolo, chunkFrames, floatBufferL, floatBufferR)

                // Master limiting & saturation
                var maxPeak = 0f
                var sumSqL = 0f
                var sumSqR = 0f

                val mVol = masterVolume.coerceIn(0f, 2f)

                for (i in 0 until chunkFrames) {
                    var outL = floatBufferL[i] * mVol
                    var outR = floatBufferR[i] * mVol

                    // Master Soft Saturation to prevent harsh digital clipping
                    outL = tanh(outL.coerceIn(-3f, 3f))
                    outR = tanh(outR.coerceIn(-3f, 3f))

                    val absL = abs(outL)
                    val absR = abs(outR)
                    if (absL > maxPeak) maxPeak = absL
                    if (absR > maxPeak) maxPeak = absR
                    sumSqL += outL * outL
                    sumSqR += outR * outR

                    // Convert to 16-bit PCM with clamp
                    val pcmL = (outL * 32767f).coerceIn(-32768f, 32767f).toInt().toShort()
                    val pcmR = (outR * 32767f).coerceIn(-32768f, 32767f).toInt().toShort()

                    shortBuffer[i * 2] = pcmL
                    shortBuffer[i * 2 + 1] = pcmR
                }

                // Write to AudioTrack
                audioTrack?.write(shortBuffer, 0, shortBuffer.size)

                // Update VU meters periodically
                meterTicker++
                if (meterTicker % 3 == 0) {
                    val rmsL = sqrt(sumSqL / chunkFrames)
                    val rmsR = sqrt(sumSqR / chunkFrames)
                    onMeterUpdate?.invoke(rmsL, rmsR, maxPeak, 0f)
                }
            }
        }
    }

    fun stop() {
        isPlaying = false
        synchronized(activeVoices) {
            activeVoices.clear()
        }
        onStepChanged?.invoke(0)
        onMeterUpdate?.invoke(0f, 0f, 0f, 0f)
    }

    fun triggerTrackSound(track: Track) {
        val baseFreq = when (track.type) {
            InstrumentType.DRUMS -> 55f
            InstrumentType.BASS -> 48f
            InstrumentType.SYNTH_LEAD -> 330f
            InstrumentType.KEYS -> 261.63f
            InstrumentType.HI_HATS -> 4000f
            InstrumentType.AUDIO_VOCAL -> 220f
        }
        val duration = when (track.type) {
            InstrumentType.DRUMS -> (sampleRate * 0.35f).toInt()
            InstrumentType.BASS -> (sampleRate * 0.45f).toInt()
            InstrumentType.SYNTH_LEAD -> (sampleRate * 0.4f).toInt()
            InstrumentType.KEYS -> (sampleRate * 0.5f).toInt()
            InstrumentType.HI_HATS -> (sampleRate * 0.08f).toInt()
            InstrumentType.AUDIO_VOCAL -> (sampleRate * 0.5f).toInt()
        }

        synchronized(activeVoices) {
            // Keep active voices count bounded
            if (activeVoices.size > 32) {
                activeVoices.removeAt(0)
            }
            activeVoices.add(Voice(track.type, baseFreq, durationSamples = duration))
        }
    }

    private fun renderTracksAudio(
        tracks: List<Track>,
        hasSolo: Boolean,
        chunkFrames: Int,
        outL: FloatArray,
        outR: FloatArray
    ) {
        // Synthesize active voices into temporary buffers per instrument
        val voiceBuffers = mutableMapOf<InstrumentType, FloatArray>()

        synchronized(activeVoices) {
            val iterator = activeVoices.iterator()
            while (iterator.hasNext()) {
                val voice = iterator.next()
                val buf = voiceBuffers.getOrPut(voice.type) { FloatArray(chunkFrames) }

                for (i in 0 until chunkFrames) {
                    if (voice.samplePos >= voice.durationSamples) {
                        voice.active = false
                        break
                    }

                    val sample = generateSample(voice)
                    buf[i] += sample
                    voice.samplePos++
                }

                if (!voice.active) {
                    iterator.remove()
                }
            }
        }

        // Process each track through its effects chain and mix into master
        for (track in tracks) {
            val isAudible = if (hasSolo) track.isSolo else !track.isMuted
            if (!isAudible) continue

            val rawSamples = voiceBuffers[track.type] ?: continue
            val trackL = FloatArray(chunkFrames)
            val trackR = FloatArray(chunkFrames)

            // Equal power panning
            val pan = track.pan.coerceIn(-1f, 1f)
            val panAngle = (pan + 1f) * (PI.toFloat() / 4f)
            val panGainL = cos(panAngle) * track.volume
            val panGainR = sin(panAngle) * track.volume

            for (i in 0 until chunkFrames) {
                trackL[i] = rawSamples[i] * panGainL
                trackR[i] = rawSamples[i] * panGainR
            }

            // Apply Track DSP chain
            val dsp = trackStates.getOrPut(track.id) { TrackDspState() }
            applyEffectsChain(track.effects, trackL, trackR, dsp, chunkFrames)

            // Accumulate to master
            for (i in 0 until chunkFrames) {
                outL[i] += trackL[i]
                outR[i] += trackR[i]
            }
        }
    }

    private fun generateSample(voice: Voice): Float {
        val t = voice.samplePos.toFloat() / sampleRate
        val progress = voice.samplePos.toFloat() / voice.durationSamples.coerceAtLeast(1)

        return when (voice.type) {
            InstrumentType.DRUMS -> {
                // 808 Kick: fast pitch drop + sine + sub thump
                val pitch = voice.notePitchHz * (1f + 3f * exp(-progress * 15f))
                val phase = 2f * PI.toFloat() * pitch * t
                val envelope = exp(-progress * 6f)
                val click = if (voice.samplePos < 120) (Math.random().toFloat() * 2f - 1f) * 0.4f else 0f
                (sin(phase) * envelope + click).coerceIn(-1f, 1f)
            }
            InstrumentType.BASS -> {
                // Sub Bass: warm saturated sine + sub harmonics
                val phase = 2f * PI.toFloat() * voice.notePitchHz * t
                val env = (1f - progress * 0.8f).coerceAtLeast(0f)
                val s1 = sin(phase)
                val s2 = sin(phase * 2f) * 0.25f
                val mixed = (s1 + s2) * env
                tanh(mixed * 1.4f)
            }
            InstrumentType.SYNTH_LEAD -> {
                // Melodic Sawtooth synth with resonant decay
                val phase1 = (voice.notePitchHz * t) % 1.0f
                val saw1 = 2f * phase1 - 1f
                val phase2 = ((voice.notePitchHz * 1.004f) * t) % 1.0f
                val saw2 = 2f * phase2 - 1f
                val env = exp(-progress * 4.5f)
                val mixed = (saw1 * 0.6f + saw2 * 0.4f) * env
                mixed * 0.6f
            }
            InstrumentType.KEYS -> {
                // Warm Rhodes / E-Piano: fundamental + 2nd + 3rd harmonic
                val f = voice.notePitchHz
                val s1 = sin(2f * PI.toFloat() * f * t)
                val s2 = sin(2f * PI.toFloat() * f * 2f * t) * 0.35f
                val s3 = sin(2f * PI.toFloat() * f * 3f * t) * 0.15f
                val env = exp(-progress * 3.8f)
                (s1 + s2 + s3) * env * 0.5f
            }
            InstrumentType.HI_HATS -> {
                // Metallic crisp noise burst
                val noise = (Math.random().toFloat() * 2f - 1f)
                val env = exp(-progress * 22f)
                noise * env * 0.7f
            }
            InstrumentType.AUDIO_VOCAL -> {
                // Resonant vocal chant tone / pulse
                val f = voice.notePitchHz
                val p = sin(2f * PI.toFloat() * f * t)
                val vibrato = sin(2f * PI.toFloat() * 5.5f * t) * 0.05f
                val formant = sin(2f * PI.toFloat() * (f * 2.8f + vibrato * 100f) * t) * 0.4f
                val env = exp(-progress * 3.0f)
                (p + formant) * env * 0.5f
            }
        }
    }

    private fun applyEffectsChain(
        effects: List<EffectInstance>,
        bufL: FloatArray,
        bufR: FloatArray,
        dsp: TrackDspState,
        frames: Int
    ) {
        for (effect in effects) {
            if (!effect.isEnabled) continue

            when (effect.type) {
                EffectType.EQ_3CHI -> {
                    val p = effect.eqParams
                    // Update filters
                    dsp.eqBandsL[0].updatePeaking(p.chi1Freq, p.chi1Gain, p.chi1Q, sampleRate.toFloat())
                    dsp.eqBandsR[0].updatePeaking(p.chi1Freq, p.chi1Gain, p.chi1Q, sampleRate.toFloat())

                    dsp.eqBandsL[1].updatePeaking(p.chi2Freq, p.chi2Gain, p.chi2Q, sampleRate.toFloat())
                    dsp.eqBandsR[1].updatePeaking(p.chi2Freq, p.chi2Gain, p.chi2Q, sampleRate.toFloat())

                    dsp.eqBandsL[2].updatePeaking(p.chi3Freq, p.chi3Gain, p.chi3Q, sampleRate.toFloat())
                    dsp.eqBandsR[2].updatePeaking(p.chi3Freq, p.chi3Gain, p.chi3Q, sampleRate.toFloat())

                    val trim = 10f.pow(p.outputTrim / 20f)
                    val drive = p.warmthDrive.coerceIn(0f, 1f) * 1.5f

                    for (i in 0 until frames) {
                        var l = bufL[i]
                        var r = bufR[i]
                        // Apply 3 bands
                        for (b in 0..2) {
                            l = dsp.eqBandsL[b].process(l)
                            r = dsp.eqBandsR[b].process(r)
                        }
                        // Warmth / saturation
                        if (drive > 0f) {
                            l = tanh(l * (1f + drive))
                            r = tanh(r * (1f + drive))
                        }
                        bufL[i] = l * trim
                        bufR[i] = r * trim
                    }
                }

                EffectType.AURA_COMP -> {
                    val p = effect.compParams
                    val attackCoeff = exp(-1f / ((p.attackMs.coerceAtLeast(0.1f) / 1000f) * sampleRate))
                    val releaseCoeff = exp(-1f / ((p.releaseMs.coerceAtLeast(1f) / 1000f) * sampleRate))
                    val makeupGain = 10f.pow(p.makeupGainDb / 20f)
                    val mix = p.mix.coerceIn(0f, 1f)

                    for (i in 0 until frames) {
                        val dryL = bufL[i]
                        val dryR = bufR[i]
                        val peak = max(abs(dryL), abs(dryR))

                        // Envelope detection
                        val target = peak
                        dsp.compEnvelope = if (target > dsp.compEnvelope) {
                            attackCoeff * dsp.compEnvelope + (1f - attackCoeff) * target
                        } else {
                            releaseCoeff * dsp.compEnvelope + (1f - releaseCoeff) * target
                        }

                        val envDb = if (dsp.compEnvelope > 1e-5f) 20f * log10(dsp.compEnvelope) else -100f
                        val overshoot = envDb - p.thresholdDb
                        var grDb = 0f
                        if (overshoot > 0f) {
                            grDb = overshoot * (1f - 1f / p.ratio.coerceAtLeast(1f))
                        }
                        dsp.compGainReduction = grDb

                        val gain = 10f.pow(-grDb / 20f) * makeupGain
                        val wetL = dryL * gain
                        val wetR = dryR * gain

                        bufL[i] = dryL * (1f - mix) + wetL * mix
                        bufR[i] = dryR * (1f - mix) + wetR * mix
                    }
                }

                EffectType.AURA_SPACE -> {
                    val p = effect.spaceParams
                    val mix = p.mix.coerceIn(0f, 1f)
                    val feedback = (p.roomSize / 10f).coerceIn(0.1f, 0.92f)
                    val damp = (p.dampingHz / 20000f).coerceIn(0.1f, 0.9f)
                    val width = p.stereoWidth.coerceIn(0f, 2f)

                    for (i in 0 until frames) {
                        val dryL = bufL[i]
                        val dryR = bufR[i]

                        // Comb filter processing
                        var revL = 0f
                        var revR = 0f

                        for (d in 0..3) {
                            val dl = dsp.revDelaysL[d].read(dsp.revDelaysL[d].size - 1)
                            val dr = dsp.revDelaysR[d].read(dsp.revDelaysR[d].size - 1)

                            dsp.revDampL = dsp.revDampL * (1f - damp) + dl * damp
                            dsp.revDampR = dsp.revDampR * (1f - damp) + dr * damp

                            dsp.revDelaysL[d].write(dryL + dsp.revDampL * feedback)
                            dsp.revDelaysR[d].write(dryR + dsp.revDampR * feedback)

                            revL += dl
                            revR += dr
                        }

                        revL *= 0.25f
                        revR *= 0.25f

                        // Stereo width matrix (Mid/Side)
                        val mid = (revL + revR) * 0.5f
                        val side = (revL - revR) * 0.5f * width

                        val wetL = mid + side
                        val wetR = mid - side

                        bufL[i] = dryL * (1f - mix) + wetL * mix
                        bufR[i] = dryR * (1f - mix) + wetR * mix
                    }
                }

                EffectType.AURA_MAXIMIZER -> {
                    val p = effect.maximizerParams
                    val driveGain = 10f.pow(p.driveDb / 20f)
                    val ceilingLinear = 10f.pow(p.ceilingDb / 20f)
                    val punch = p.transientPunch.coerceIn(0f, 1f)

                    for (i in 0 until frames) {
                        var l = bufL[i] * driveGain
                        var r = bufR[i] * driveGain

                        // Transient punch expansion
                        if (punch > 0f) {
                            val mag = max(abs(l), abs(r))
                            if (mag > 0.4f) {
                                val boost = 1f + punch * 0.5f
                                l *= boost
                                r *= boost
                            }
                        }

                        // Saturation / Brickwall Limiting curve
                        l = (tanh(l / ceilingLinear) * ceilingLinear).coerceIn(-ceilingLinear, ceilingLinear)
                        r = (tanh(r / ceilingLinear) * ceilingLinear).coerceIn(-ceilingLinear, ceilingLinear)

                        bufL[i] = l
                        bufR[i] = r
                    }
                }
            }
        }
    }

    fun release() {
        isPlaying = false
        playbackJob?.cancel()
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        audioTrack = null
    }
}
