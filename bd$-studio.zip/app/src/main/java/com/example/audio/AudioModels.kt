package com.example.audio

import java.util.UUID

enum class InstrumentType(val displayName: String, val iconName: String) {
    DRUMS("808 Drums", "Drum"),
    BASS("Sub Bass", "Bass"),
    SYNTH_LEAD("Lead Synth", "Synth"),
    KEYS("Rhodes Keys", "Piano"),
    HI_HATS("Trap Hats", "Hats"),
    AUDIO_VOCAL("Audio / Mic", "Mic")
}

enum class EffectType(val displayName: String, val badgeColorHex: Long) {
    EQ_3CHI("EQ 3CHI", 0xFFFFC107),
    AURA_COMP("AuraComp", 0xFF00E5FF),
    AURA_SPACE("AuraSpace", 0xFFB388FF),
    AURA_MAXIMIZER("AuraMaximizer", 0xFFFF9100)
}

data class EQ3ChiParams(
    val chi1Freq: Float = 100f,
    val chi1Gain: Float = 0f,
    val chi1Q: Float = 1.0f,
    val chi2Freq: Float = 1200f,
    val chi2Gain: Float = 0f,
    val chi2Q: Float = 1.0f,
    val chi3Freq: Float = 8000f,
    val chi3Gain: Float = 0f,
    val chi3Q: Float = 1.0f,
    val warmthDrive: Float = 0.0f,
    val outputTrim: Float = 0.0f
)

data class AuraCompParams(
    val thresholdDb: Float = -18f,
    val ratio: Float = 4.0f,
    val attackMs: Float = 15f,
    val releaseMs: Float = 120f,
    val kneeDb: Float = 4.0f,
    val makeupGainDb: Float = 3.0f,
    val mix: Float = 1.0f
)

data class AuraSpaceParams(
    val roomSize: Float = 2.5f,
    val preDelayMs: Float = 20f,
    val dampingHz: Float = 7500f,
    val stereoWidth: Float = 1.2f,
    val diffusion: Float = 0.8f,
    val mix: Float = 0.35f,
    val spaceType: String = "Hall"
)

data class AuraMaximizerParams(
    val ceilingDb: Float = -0.3f,
    val driveDb: Float = 4.0f,
    val releaseMs: Float = 60f,
    val transientPunch: Float = 0.4f,
    val character: String = "Warm"
)

data class EffectInstance(
    val id: String = UUID.randomUUID().toString(),
    val type: EffectType,
    val isEnabled: Boolean = true,
    val eqParams: EQ3ChiParams = EQ3ChiParams(),
    val compParams: AuraCompParams = AuraCompParams(),
    val spaceParams: AuraSpaceParams = AuraSpaceParams(),
    val maximizerParams: AuraMaximizerParams = AuraMaximizerParams()
)

data class Track(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: InstrumentType,
    val colorHex: Long,
    val volume: Float = 0.8f,
    val pan: Float = 0.0f,
    val isMuted: Boolean = false,
    val isSolo: Boolean = false,
    val effects: List<EffectInstance> = emptyList(),
    val steps: BooleanArray = BooleanArray(16) { false },
    val isRecordingArmed: Boolean = false
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as Track
        if (id != other.id) return false
        if (name != other.name) return false
        if (type != other.type) return false
        if (colorHex != other.colorHex) return false
        if (volume != other.volume) return false
        if (pan != other.pan) return false
        if (isMuted != other.isMuted) return false
        if (isSolo != other.isSolo) return false
        if (effects != other.effects) return false
        if (!steps.contentEquals(other.steps)) return false
        if (isRecordingArmed != other.isRecordingArmed) return false
        return true
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + name.hashCode()
        result = 31 * result + type.hashCode()
        result = 31 * result + colorHex.hashCode()
        result = 31 * result + volume.hashCode()
        result = 31 * result + pan.hashCode()
        result = 31 * result + isMuted.hashCode()
        result = 31 * result + isSolo.hashCode()
        result = 31 * result + effects.hashCode()
        result = 31 * result + steps.contentHashCode()
        result = 31 * result + isRecordingArmed.hashCode()
        return result
    }
}

data class MasterState(
    val volume: Float = 0.85f,
    val bpm: Int = 128,
    val isPlaying: Boolean = false,
    val isRecording: Boolean = false,
    val loopEnabled: Boolean = true,
    val metronomeEnabled: Boolean = false,
    val currentStep: Int = 0,
    val currentBar: Int = 1,
    val masterRmsLeft: Float = 0f,
    val masterRmsRight: Float = 0f,
    val masterPeak: Float = 0f,
    val gainReductionComp: Float = 0f,
    val maximizerGr: Float = 0f
)
