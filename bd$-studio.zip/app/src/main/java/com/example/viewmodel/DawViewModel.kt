package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DawViewModel : ViewModel() {

    val audioEngine = AudioEngine()

    private val _tracks = MutableStateFlow<List<Track>>(emptyList())
    val tracks: StateFlow<List<Track>> = _tracks.asStateFlow()

    private val _masterState = MutableStateFlow(MasterState())
    val masterState: StateFlow<MasterState> = _masterState.asStateFlow()

    // Screen navigation state:
    // If activeEffectTrackId and activeEffectId are not null, show that effect's dedicated interface!
    // Otherwise show main DAW multitrack view.
    private val _activeEffectTrackId = MutableStateFlow<String?>(null)
    val activeEffectTrackId: StateFlow<String?> = _activeEffectTrackId.asStateFlow()

    private val _activeEffectId = MutableStateFlow<String?>(null)
    val activeEffectId: StateFlow<String?> = _activeEffectId.asStateFlow()

    init {
        loadDefaultProject()

        audioEngine.onStepChanged = { step ->
            _masterState.value = _masterState.value.copy(
                currentStep = step,
                currentBar = (step / 4) + 1
            )
        }

        audioEngine.onMeterUpdate = { rmsL, rmsR, peak, compGr ->
            _masterState.value = _masterState.value.copy(
                masterRmsLeft = rmsL,
                masterRmsRight = rmsR,
                masterPeak = peak,
                gainReductionComp = compGr
            )
        }
    }

    private fun loadDefaultProject() {
        val defaultTracks = listOf(
            Track(
                name = "808 Drums",
                type = InstrumentType.DRUMS,
                colorHex = 0xFF00E5FF,
                volume = 0.85f,
                pan = 0.0f,
                steps = booleanArrayOf(
                    true, false, false, false,
                    true, false, false, false,
                    true, false, false, false,
                    true, false, false, false
                ),
                effects = listOf(
                    EffectInstance(
                        type = EffectType.EQ_3CHI,
                        eqParams = EQ3ChiParams(chi1Gain = 3.5f, chi1Freq = 80f, warmthDrive = 0.2f)
                    ),
                    EffectInstance(
                        type = EffectType.AURA_COMP,
                        compParams = AuraCompParams(thresholdDb = -14f, ratio = 4.5f, makeupGainDb = 2.5f)
                    )
                )
            ),
            Track(
                name = "Trap Hats",
                type = InstrumentType.HI_HATS,
                colorHex = 0xFFFFC107,
                volume = 0.70f,
                pan = 0.2f,
                steps = booleanArrayOf(
                    true, false, true, false,
                    true, false, true, true,
                    true, false, true, false,
                    true, true, true, true
                ),
                effects = listOf(
                    EffectInstance(
                        type = EffectType.AURA_SPACE,
                        spaceParams = AuraSpaceParams(mix = 0.25f, roomSize = 1.8f, dampingHz = 12000f)
                    )
                )
            ),
            Track(
                name = "Sub 808 Bass",
                type = InstrumentType.BASS,
                colorHex = 0xFFB388FF,
                volume = 0.90f,
                pan = -0.1f,
                steps = booleanArrayOf(
                    true, false, false, false,
                    false, false, true, false,
                    true, false, false, false,
                    false, true, false, false
                ),
                effects = listOf(
                    EffectInstance(
                        type = EffectType.AURA_MAXIMIZER,
                        maximizerParams = AuraMaximizerParams(driveDb = 5.0f, ceilingDb = -0.5f, transientPunch = 0.6f)
                    )
                )
            ),
            Track(
                name = "Lead Pluck",
                type = InstrumentType.SYNTH_LEAD,
                colorHex = 0xFF00E676,
                volume = 0.75f,
                pan = -0.25f,
                steps = booleanArrayOf(
                    true, false, true, false,
                    false, true, false, false,
                    true, false, false, true,
                    false, false, true, false
                ),
                effects = listOf(
                    EffectInstance(
                        type = EffectType.EQ_3CHI,
                        eqParams = EQ3ChiParams(chi2Gain = 2.0f, chi3Gain = 4.0f, warmthDrive = 0.15f)
                    ),
                    EffectInstance(
                        type = EffectType.AURA_SPACE,
                        spaceParams = AuraSpaceParams(mix = 0.45f, roomSize = 4.2f, stereoWidth = 1.5f)
                    )
                )
            )
        )

        _tracks.value = defaultTracks
        syncAudioEngine()
    }

    private fun syncAudioEngine() {
        audioEngine.currentTracks = _tracks.value
        audioEngine.bpm = _masterState.value.bpm
        audioEngine.masterVolume = _masterState.value.volume
        audioEngine.loopEnabled = _masterState.value.loopEnabled
        audioEngine.metronomeEnabled = _masterState.value.metronomeEnabled
    }

    // Transport controls
    fun togglePlay() {
        if (_masterState.value.isPlaying) {
            audioEngine.stop()
            _masterState.value = _masterState.value.copy(isPlaying = false)
        } else {
            syncAudioEngine()
            audioEngine.start()
            _masterState.value = _masterState.value.copy(isPlaying = true)
        }
    }

    fun stop() {
        audioEngine.stop()
        _masterState.value = _masterState.value.copy(isPlaying = false, currentStep = 0)
    }

    fun setBpm(newBpm: Int) {
        val clamped = newBpm.coerceIn(50, 240)
        _masterState.value = _masterState.value.copy(bpm = clamped)
        audioEngine.bpm = clamped
    }

    fun setMasterVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1.5f)
        _masterState.value = _masterState.value.copy(volume = clamped)
        audioEngine.masterVolume = clamped
    }

    fun toggleMetronome() {
        val current = _masterState.value.metronomeEnabled
        _masterState.value = _masterState.value.copy(metronomeEnabled = !current)
        audioEngine.metronomeEnabled = !current
    }

    fun toggleLoop() {
        val current = _masterState.value.loopEnabled
        _masterState.value = _masterState.value.copy(loopEnabled = !current)
        audioEngine.loopEnabled = !current
    }

    fun toggleRecord() {
        val current = _masterState.value.isRecording
        _masterState.value = _masterState.value.copy(isRecording = !current)
        if (!current && !_masterState.value.isPlaying) {
            togglePlay()
        }
    }

    // Track controls
    fun addTrack(type: InstrumentType, customName: String? = null) {
        val colors = listOf(0xFF00E5FF, 0xFFFFC107, 0xFFB388FF, 0xFF00E676, 0xFFFF9100, 0xFF2979FF)
        val name = customName ?: "${type.displayName} ${_tracks.value.count { it.type == type } + 1}"
        val color = colors[(_tracks.value.size) % colors.size]

        val newTrack = Track(
            name = name,
            type = type,
            colorHex = color,
            volume = 0.8f,
            pan = 0.0f
        )
        _tracks.value = _tracks.value + newTrack
        syncAudioEngine()
    }

    fun deleteTrack(trackId: String) {
        _tracks.value = _tracks.value.filter { it.id != trackId }
        if (_activeEffectTrackId.value == trackId) {
            closeEffectScreen()
        }
        syncAudioEngine()
    }

    fun updateTrackVolume(trackId: String, volume: Float) {
        _tracks.value = _tracks.value.map {
            if (it.id == trackId) it.copy(volume = volume.coerceIn(0f, 1.5f)) else it
        }
        syncAudioEngine()
    }

    fun updateTrackPan(trackId: String, pan: Float) {
        _tracks.value = _tracks.value.map {
            if (it.id == trackId) it.copy(pan = pan.coerceIn(-1f, 1f)) else it
        }
        syncAudioEngine()
    }

    fun toggleTrackMute(trackId: String) {
        _tracks.value = _tracks.value.map {
            if (it.id == trackId) it.copy(isMuted = !it.isMuted) else it
        }
        syncAudioEngine()
    }

    fun toggleTrackSolo(trackId: String) {
        _tracks.value = _tracks.value.map {
            if (it.id == trackId) it.copy(isSolo = !it.isSolo) else it
        }
        syncAudioEngine()
    }

    fun toggleStep(trackId: String, stepIndex: Int) {
        _tracks.value = _tracks.value.map { track ->
            if (track.id == trackId && stepIndex in 0 until 16) {
                val newSteps = track.steps.clone()
                newSteps[stepIndex] = !newSteps[stepIndex]
                track.copy(steps = newSteps)
            } else {
                track
            }
        }
        syncAudioEngine()
    }

    fun previewTrack(trackId: String) {
        val track = _tracks.value.find { it.id == trackId } ?: return
        audioEngine.triggerTrackSound(track)
    }

    // Effect management
    fun addEffectToTrack(trackId: String, effectType: EffectType) {
        val newEffect = EffectInstance(
            type = effectType,
            isEnabled = true
        )
        _tracks.value = _tracks.value.map { track ->
            if (track.id == trackId) {
                track.copy(effects = track.effects + newEffect)
            } else {
                track
            }
        }
        syncAudioEngine()
    }

    fun removeEffectFromTrack(trackId: String, effectId: String) {
        _tracks.value = _tracks.value.map { track ->
            if (track.id == trackId) {
                track.copy(effects = track.effects.filter { it.id != effectId })
            } else {
                track
            }
        }
        if (_activeEffectTrackId.value == trackId && _activeEffectId.value == effectId) {
            closeEffectScreen()
        }
        syncAudioEngine()
    }

    fun toggleEffectBypass(trackId: String, effectId: String) {
        _tracks.value = _tracks.value.map { track ->
            if (track.id == trackId) {
                val updatedEffects = track.effects.map { eff ->
                    if (eff.id == effectId) eff.copy(isEnabled = !eff.isEnabled) else eff
                }
                track.copy(effects = updatedEffects)
            } else {
                track
            }
        }
        syncAudioEngine()
    }

    // Navigation to / from effect screens
    fun openEffect(trackId: String, effectId: String) {
        _activeEffectTrackId.value = trackId
        _activeEffectId.value = effectId
    }

    fun closeEffectScreen() {
        _activeEffectTrackId.value = null
        _activeEffectId.value = null
    }

    // Effect parameter updates
    fun updateEQ3ChiParams(trackId: String, effectId: String, params: EQ3ChiParams) {
        _tracks.value = _tracks.value.map { track ->
            if (track.id == trackId) {
                track.copy(effects = track.effects.map { eff ->
                    if (eff.id == effectId) eff.copy(eqParams = params) else eff
                })
            } else {
                track
            }
        }
        syncAudioEngine()
    }

    fun updateAuraCompParams(trackId: String, effectId: String, params: AuraCompParams) {
        _tracks.value = _tracks.value.map { track ->
            if (track.id == trackId) {
                track.copy(effects = track.effects.map { eff ->
                    if (eff.id == effectId) eff.copy(compParams = params) else eff
                })
            } else {
                track
            }
        }
        syncAudioEngine()
    }

    fun updateAuraSpaceParams(trackId: String, effectId: String, params: AuraSpaceParams) {
        _tracks.value = _tracks.value.map { track ->
            if (track.id == trackId) {
                track.copy(effects = track.effects.map { eff ->
                    if (eff.id == effectId) eff.copy(spaceParams = params) else eff
                })
            } else {
                track
            }
        }
        syncAudioEngine()
    }

    fun updateAuraMaximizerParams(trackId: String, effectId: String, params: AuraMaximizerParams) {
        _tracks.value = _tracks.value.map { track ->
            if (track.id == trackId) {
                track.copy(effects = track.effects.map { eff ->
                    if (eff.id == effectId) eff.copy(maximizerParams = params) else eff
                })
            } else {
                track
            }
        }
        syncAudioEngine()
    }

    // Project Presets
    fun loadPreset(presetName: String) {
        when (presetName) {
            "Latin Trap 808" -> {
                setBpm(130)
                loadDefaultProject()
            }
            "Cyberpunk Synth" -> {
                setBpm(110)
                _tracks.value = listOf(
                    Track(
                        name = "Kick & Snare",
                        type = InstrumentType.DRUMS,
                        colorHex = 0xFFFF1744,
                        steps = booleanArrayOf(true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false)
                    ),
                    Track(
                        name = "Sub Saw Bass",
                        type = InstrumentType.BASS,
                        colorHex = 0xFF00E5FF,
                        steps = booleanArrayOf(true, true, false, true, true, false, true, false, true, true, false, true, false, true, true, false),
                        effects = listOf(EffectInstance(type = EffectType.EQ_3CHI, eqParams = EQ3ChiParams(chi1Gain = 4f, warmthDrive = 0.4f)))
                    ),
                    Track(
                        name = "Cyber Synth",
                        type = InstrumentType.SYNTH_LEAD,
                        colorHex = 0xFFFFC107,
                        steps = booleanArrayOf(true, false, false, true, false, true, false, false, true, false, false, true, false, false, true, true),
                        effects = listOf(EffectInstance(type = EffectType.AURA_SPACE, spaceParams = AuraSpaceParams(mix = 0.5f, roomSize = 5f)))
                    )
                )
                syncAudioEngine()
            }
            "Lo-Fi Chill" -> {
                setBpm(85)
                _tracks.value = listOf(
                    Track(
                        name = "Dusty Rhodes",
                        type = InstrumentType.KEYS,
                        colorHex = 0xFFFF9100,
                        steps = booleanArrayOf(true, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false),
                        effects = listOf(EffectInstance(type = EffectType.AURA_SPACE, spaceParams = AuraSpaceParams(mix = 0.4f, roomSize = 3.5f)))
                    ),
                    Track(
                        name = "Lo-Fi Beats",
                        type = InstrumentType.DRUMS,
                        colorHex = 0xFFB388FF,
                        steps = booleanArrayOf(true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false),
                        effects = listOf(EffectInstance(type = EffectType.AURA_COMP, compParams = AuraCompParams(thresholdDb = -18f, ratio = 6f)))
                    )
                )
                syncAudioEngine()
            }
        }
    }

    fun clearProject() {
        stop()
        _tracks.value = emptyList()
        syncAudioEngine()
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.release()
    }
}
